# FightFit AI – Landingpage

Diese Mappe ist deploy‑fertig (statisch).

## So veröffentlichst du die Seite
1) **ZIP hochladen** bei Netlify/Vercel oder auf deinen Hoster.
   - Netlify: Neues Projekt → „Deploy site“ → ZIP hochladen.
   - Vercel: „New Project“ → „Import…“ → lade ZIP nach GitHub hoch und importiere es.
2) In `index.html` ersetze die Platzhalter‑Links (App‑Store/Play‑Store, Impressum/Datenschutz/AGB, Formspree‑ID).
3) Ersetze Platzhalter‑Grafiken in `assets/` durch echte Bilder:
   - `logo.svg`, `hero.png`, `og.jpg`

## Optional
- Analytics/Pixel einbauen
- Sitemap/robots ergänzen (statisch)

Viel Erfolg!
