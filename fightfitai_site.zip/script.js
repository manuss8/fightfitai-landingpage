
(function(){
  // Simple A/B: if URL contains ?v=b change CTA & headline
  const params=new URLSearchParams(location.search);
  const variant=params.get('v');
  if(variant==='b'){
    document.querySelectorAll('.cta-text').forEach(el=>el.textContent='Kostenlos testen – in 60 Sek. starten');
    const h=document.querySelector('#headline'); if(h){h.textContent='Dein KI‑Boxcoach. Schneller Fortschritt – garantiert.'}
  }
  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{
    const id=a.getAttribute('href').slice(1); const el=document.getElementById(id); if(!el) return;
    e.preventDefault(); el.scrollIntoView({behavior:'smooth'});
  }));
  // Replace tracking placeholders if provided via data attributes
  // GA4
  const GA_ID=document.body.dataset.ga || '';
  if(GA_ID){
    const s1=document.createElement('script'); s1.async=true; s1.src=`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`; document.head.appendChild(s1);
    window.dataLayer=window.dataLayer||[]; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', GA_ID);
  }
  // Meta Pixel
  const FB_ID=document.body.dataset.fb || '';
  if(FB_ID){
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod? n.callMethod.apply(n,arguments):n.queue.push(arguments)}; if(!f._fbq)f._fbq=n; n.push=n; n.loaded=!0;n.version='2.0'; n.queue=[]; t=b.createElement(e); t.async=!0; t.src=v; s=b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js'); fbq('init', FB_ID); fbq('track', 'PageView');
  }
  // TikTok Pixel
  const TT_ID=document.body.dataset.tt || '';
  if(TT_ID){
    !function (w, d, t) { w.TiktokAnalyticsObject=t; var ttq=w[t]=w[t]||[]; ttq.methods=['page','track']; ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}; for (var i=0;i<ttq.methods.length;i++) ttq.setAndDefer(ttq, ttq.methods[i]); ttq.load=function(e){ var i='https://analytics.tiktok.com/i18n/pixel/events.js'; ttq._i=ttq._i||[]; ttq._i.push([e]); var a=document.createElement('script'); a.type='text/javascript'; a.async=!0; a.src=i; var s=document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(a, s)}; ttq.load(TT_ID); ttq.page();
    }(window, document, 'ttq');
  }
})();
