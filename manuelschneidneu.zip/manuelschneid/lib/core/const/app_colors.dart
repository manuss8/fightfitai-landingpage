import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFFB3E429);
  static const Color backgroundColor = Color(0xFFF4F4F4);
  static const Color appBackgroundColor = Color(0xFF242424);
}
