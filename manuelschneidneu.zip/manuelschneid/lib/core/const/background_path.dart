class BackgroundImagePath {
  static const String background =
      'assets/backgrounds/verification_code_screen.png';
  static const String forgetPasswordemail =
      'assets/backgrounds/forget_password.png';
  static const String forgetPasswordOtpVarification =
      'assets/backgrounds/otpBackground.png';
}
