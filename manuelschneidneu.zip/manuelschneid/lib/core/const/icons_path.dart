class IconsPath {
  static const String activeProfile = "assets/icons/activeProfile.png";
  static const String logout = "assets/icons/logout.png";
  static const String editProfile = "assets/icons/profileEditIcon.png";
  static const String lockIcon = "assets/icons/lockIcon.png";
  static const String sendButton = "assets/icons/sendButton.png";
  static const String clock = "assets/icons/clcok.png";
  static const String reload = "assets/icons/reloadIcon.png";
  static const String editIcon = "assets/icons/editIcon.png";
  static const String courseList = "assets/icons/courseList.png";
  static const String profileAvater = "assets/icons/profile_ava.png";
  static const String upgrade = "assets/icons/upgrade.png";
  static const String subscription = "assets/icons/subscription.png";
  static const String dropdown = "assets/icons/dropdown.png";

  static const String activeHome = "assets/icons/activeHome.png";
  static const String activeCoach = "assets/icons/activeCoach.png";
  static const String activeGoal = "assets/icons/activeGoal.png";
  static const String activeTraining = "assets/icons/activeTraining.png";
  static const String activeNeut = "assets/icons/activeNeut.png";
}
