class BottomNavbarImagePath {
  static const String activeHome = 'assets/bottomNavbarIcons/activeHome.png';
  static const String inactiveHome =
      'assets/bottomNavbarIcons/inactiveHome.png';
  static const String activeTraining =
      'assets/bottomNavbarIcons/activeTraining.png';
  static const String inactiveTraining =
      'assets/bottomNavbarIcons/inactiveTraining.png';
  static const String inactiveCoach =
      'assets/bottomNavbarIcons/inactiveCoach.png';
  static const String activeCoach = 'assets/bottomNavbarIcons/activeCoach.png';
  static const String activeGoal = 'assets/bottomNavbarIcons/activeGoal.png';
  static const String inactiveGoal =
      'assets/bottomNavbarIcons/inactiveGoal.png';
  static const String activeNeut = 'assets/bottomNavbarIcons/activeNeut.png';
  static const String inactiveNeut =
      'assets/bottomNavbarIcons/inactiveNeut.png';
}
