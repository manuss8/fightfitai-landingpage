class ImagePath {
  static const String appImage = 'assets/appImage/robot.png';
  static const String userImage = 'assets/images/userImage.png';
  static const String notification = 'assets/images/notification.png';
  static const String homeImage = 'assets/images/home_image.png';
  static const String trainingCategory = 'assets/images/trainingCategory.png';
  static const String userImage2 = 'assets/images/userImage2.png';
  static const String alertImage = 'assets/images/alertBackground.png';
  static const String badge = 'assets/images/badge.png';
  static const String sunflower = 'assets/images/sunflower.png';
  static const String aiq1 = 'assets/appImage/robot.png';
  static const String aiq2 = 'assets/images/aiq2.png';
  static const String aiq3 = 'assets/images/aiq3.png';
}
