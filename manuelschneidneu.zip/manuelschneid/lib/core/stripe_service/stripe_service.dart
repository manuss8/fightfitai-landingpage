// import 'package:dio/dio.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter_stripe/flutter_stripe.dart';
// import 'package:manuelschneid/core/stripe_service/const.dart';

// class StripeService {
//   StripeService._();

//   static final StripeService instance = StripeService._();

//   Future<bool> makePayment(double amount, String currency) async {
//     try {
//       String? paymentIntentClientSecret = await _createPaymentIntent(
//         amount,
//         currency,
//       );
//       if (kDebugMode) {
//         print("Client Secret to be used: $paymentIntentClientSecret");
//       }
//       if (paymentIntentClientSecret == null) {
//         if (kDebugMode) {
//           print("Payment Intent creation failed.");
//         }
//         return false;
//       }

//       await Stripe.instance.initPaymentSheet(
//         paymentSheetParameters: SetupPaymentSheetParameters(
//           paymentIntentClientSecret: paymentIntentClientSecret,
//           merchantDisplayName: "Hido",
//           allowsDelayedPaymentMethods: true,
//         ),
//       );

//       bool isPaymentSuccess = await _processPayment();
//       if (kDebugMode) {
//         print("////////////Payment successful result: $isPaymentSuccess");
//       }
//       return isPaymentSuccess;
//     } catch (e) {
//       if (kDebugMode) {
//         print("Payment failed: $e");
//       }
//       return false;
//     }
//   }

//   Future<bool> _processPayment() async {
//     try {
//       if (kDebugMode) {
//         print("////////// Presenting payment sheet...");
//       }
//       await Stripe.instance.presentPaymentSheet();
//       if (kDebugMode) {
//         print("////////// Payment confirmed successfully!");
//       }
//       return true;
//     } catch (e) {
//       if (kDebugMode) {
//         print("Error processing payment: $e");
//       }
//       return false;
//     }
//   }

//   Future<String?> _createPaymentIntent(double amount, String currency) async {
//     try {
//       final Dio dio = Dio();
//       Map<String, dynamic> data = {
//         "amount": _calculateAmount(amount),
//         "currency": currency,
//         "payment_method_types[]": "card",
//       };
//       if (kDebugMode) {
//         print("Creating Payment Intent with data: $data");
//         print(
//           "Using secret key (redacted): ${stripeSecretKey.substring(0, 8)}...",
//         );
//       }
//       var response = await dio.post(
//         "https://api.stripe.com/v1/payment_intents",
//         data: data,
//         options: Options(
//           contentType: Headers.formUrlEncodedContentType,
//           headers: {
//             "Authorization": "Bearer $stripeSecretKey",
//             "Content-Type": 'application/x-www-form-urlencoded',
//           },
//         ),
//       );
//       if (kDebugMode) {
//         print("Response Status Code: ${response.statusCode}");
//         print("Response Data: ${response.data}");
//       }
//       if (response.data != null && response.data["client_secret"] != null) {
//         final clientSecret = response.data["client_secret"];
//         if (kDebugMode) {
//           print("Extracted client_secret: $clientSecret");
//         }
//         return clientSecret;
//       }
//       if (kDebugMode) {
//         print("No client_secret in response");
//       }
//       return null;
//     } catch (e) {
//       if (e is DioException) {
//         if (kDebugMode) {
//           print(
//             "DioException: ${e.response?.statusCode} - ${e.response?.data}",
//           );
//           print("Error details: ${e.message}");
//         }
//       } else {
//         if (kDebugMode) {
//           print("Unexpected error: $e");
//         }
//       }
//       return null;
//     }
//   }

//   String _calculateAmount(double amount) {
//     final calculatedAmount =
//         (amount * 100).round(); // Stripe needs cents as int
//     return calculatedAmount.toString();
//   }
// }
