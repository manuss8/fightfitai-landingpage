// import 'package:flutter/material.dart';
// import 'package:manuelschneid/core/style/global_text_style.dart';

// class CustomDropdown extends StatefulWidget {
//   final List<String> items;
//   final String hintText;
//   final TextEditingController controller;
//   final String? initialValue;
//   final bool waitForInitialValue;

//   const CustomDropdown({
//     super.key,
//     required this.items,
//     required this.hintText,
//     required this.controller,
//     this.initialValue,
//     this.waitForInitialValue = false,
//   });

//   @override
//   // ignore: library_private_types_in_public_api
//   _CustomDropdownState createState() => _CustomDropdownState();
// }

// class _CustomDropdownState extends State<CustomDropdown> {
//   String? selectedItem;

//   @override
//   void initState() {
//     super.initState();
//     _initializeValue();
//   }

//   @override
//   void didUpdateWidget(CustomDropdown oldWidget) {
//     super.didUpdateWidget(oldWidget);
//     if (oldWidget.controller != widget.controller ||
//         oldWidget.initialValue != widget.initialValue) {
//       _initializeValue();
//     }
//   }

//   void _initializeValue() {
//     // Only set initial value if controller has text or initialValue is provided
//     if (widget.controller.text.isNotEmpty || widget.initialValue != null) {
//       selectedItem =
//           widget.controller.text.isNotEmpty
//               ? widget.controller.text
//               : widget.initialValue;

//       if (selectedItem != null && widget.controller.text.isEmpty) {
//         widget.controller.text = selectedItem!;
//       }
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final itemSet = widget.items.toSet().toList();
//     final currentValue = itemSet.contains(selectedItem) ? selectedItem : null;

//     // Show placeholder if waiting for initial value
//     if (widget.waitForInitialValue && currentValue == null) {
//       return Container(
//         padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 16),
//         decoration: BoxDecoration(
//           color: const Color(0xFFFFFFFF).withAlpha(10),
//           borderRadius: BorderRadius.circular(24),
//         ),
//         child: Text(
//           widget.hintText,
//           style: globalTextStyle(
//             fontWeight: FontWeight.w500,
//             fontSize: 14,
//             color: Colors.red.withAlpha(230),
//           ),
//         ),
//       );
//     }

//     return Theme(
//       data: Theme.of(
//         context,
//       ).copyWith(canvasColor: const Color(0xFFFFFFFF).withValues(alpha: 0.40)),
//       child: DropdownButtonFormField<String>(
//         value: currentValue,
//         items:
//             itemSet.map((String item) {
//               return DropdownMenuItem<String>(
//                 value: item,
//                 child: Padding(
//                   padding: const EdgeInsets.all(2.0),
//                   child: Text(
//                     item,
//                     style: globalTextStyle(
//                       fontWeight: FontWeight.w500,
//                       fontSize: 14,
//                       color: Colors.white,
//                     ),
//                   ),
//                 ),
//               );
//             }).toList(),
//         onChanged: (String? newValue) {
//           setState(() {
//             selectedItem = newValue;
//             widget.controller.text = newValue ?? '';
//           });
//         },
//         decoration: InputDecoration(
//           hintText: widget.hintText,
//           hintStyle: globalTextStyle(
//             fontWeight: FontWeight.w500,
//             fontSize: 14,
//             color: Colors.red.withAlpha(230),
//           ),
//           filled: true,
//           fillColor: const Color(0xFFFFFFFF).withAlpha(10),
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(24),
//             borderSide: BorderSide.none,
//           ),
//           contentPadding: const EdgeInsets.symmetric(
//             horizontal: 25,
//             vertical: 16,
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';

class CustomDropdown extends StatefulWidget {
  final List<String> items;
  final String hintText;
  final TextEditingController controller;
  final String? initialValue;
  final bool waitForInitialValue;

  const CustomDropdown({
    super.key,
    required this.items,
    required this.hintText,
    required this.controller,
    this.initialValue,
    this.waitForInitialValue = false,
  });

  @override
  // ignore: library_private_types_in_public_api
  _CustomDropdownState createState() => _CustomDropdownState();
}

class _CustomDropdownState extends State<CustomDropdown> {
  String? selectedItem;

  @override
  void initState() {
    super.initState();
    _initializeValue();
  }

  @override
  void didUpdateWidget(CustomDropdown oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller ||
        oldWidget.initialValue != widget.initialValue) {
      _initializeValue();
    }
  }

  void _initializeValue() {
    if (widget.controller.text.isNotEmpty || widget.initialValue != null) {
      selectedItem =
          widget.controller.text.isNotEmpty
              ? widget.controller.text
              : widget.initialValue;

      if (selectedItem != null && widget.controller.text.isEmpty) {
        widget.controller.text = selectedItem!;
      }
    }
  }

  void _showDropdown() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 50,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                SizedBox(height: 20),
                ...widget.items.map((item) {
                  return ListTile(
                    title: Text(
                      item,
                      style: globalTextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        selectedItem = item;
                        widget.controller.text = item;
                      });
                      Navigator.pop(context);
                    },
                  );
                }),
                SizedBox(height: 20),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.waitForInitialValue && selectedItem == null) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Text(
          widget.hintText,
          style: globalTextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: Colors.white70,
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: _showDropdown,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                selectedItem ?? widget.hintText,
                style: globalTextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                  color: Colors.white60, // Now ALL text will be white
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Image.asset(IconsPath.dropdown, color: Colors.white60, height: 24),
          ],
        ),
      ),
    );
  }
}
