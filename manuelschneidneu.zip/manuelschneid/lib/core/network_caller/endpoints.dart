class Urls {
  // static const String baseUrl =
  //     'https://manuelschneid-backend.vercel.app/api/v1';

  // static const String baseUrl =
  //     'https://jm9ffg7n-5005.inc1.devtunnels.ms/api/v1';

  static const String baseUrl = "http://45.55.155.10:5099/api/v1";

  static const String login = '$baseUrl/auth/login';
  static const String register = '$baseUrl/users/register';
  static const String verifyOtp = '$baseUrl/auth/verify-otp';
  static const String forgetPassword = '$baseUrl/auth/forgot-password';
  static const String resetPassword = '$baseUrl/auth/reset-password';
  static const String resendOTP = '$baseUrl/auth/resend-otp';
  static const String getUser = '$baseUrl/auth/profile';
  static const String updateProfile = '$baseUrl/users/profile';
  static const String changePassword = '$baseUrl/auth/change-password';
  static const String getcategory = '$baseUrl/category';
  static const String addcategory = '$baseUrl/category';
  static const String getcourse = '$baseUrl/course';
  static const String addcourse = '$baseUrl/course';
  static const String postNotificationss =
      '$baseUrl/notifications/send-notification';
}
