import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:manuelschneid/core/const/language_text.dart';
import 'package:manuelschneid/firebase_options.dart';
import 'package:manuelschneid/route/app_route.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await GetStorage.init();

  final box = GetStorage();
  if (box.read('language') == null) {
    // Set default language to German
    box.write('language', 'en');
  }
  //Stripe.publishableKey = stripePublishableKey;
  configEasyLoading();
  runApp(const MyApp());
}

void configEasyLoading() {
  EasyLoading.instance
    ..loadingStyle = EasyLoadingStyle.custom
    ..backgroundColor = Colors.grey
    ..textColor = Colors.white
    ..indicatorColor = Colors.white
    ..maskColor = Colors.green
    ..userInteractions = false
    ..dismissOnTap = false;
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final box = GetStorage();
    final savedLang = box.read('language') ?? 'de';
    final locale = Locale(savedLang, savedLang == 'de' ? 'DE' : 'US');

    ////////////////////////////

    // final Locale initialLocale =
    //     savedLang == 'de' ? const Locale('de', 'DE') : const Locale('en', 'US');

    return ScreenUtilInit(
      designSize: const Size(360, 640),
      minTextAdapt: true,
      splitScreenMode: true,
      builder:
          (context, child) => GetMaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'manuelschneid',
            translations: LocalString(),
            locale: locale,
            fallbackLocale: const Locale('de', 'DE'),
            getPages: AppRoute.routes,
            initialRoute: AppRoute.splashScreen,
            theme: ThemeData(scaffoldBackgroundColor: const Color(0xffF1F1F3)),
            builder: EasyLoading.init(),
          ),
    );
  }
}
