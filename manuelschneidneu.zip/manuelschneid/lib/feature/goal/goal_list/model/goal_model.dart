class WorkoutPlanResponse {
  final bool success;
  final String message;
  final List<WorkoutPlan> data;

  WorkoutPlanResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  factory WorkoutPlanResponse.fromJson(Map<String, dynamic> json) {
    return WorkoutPlanResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data:
          (json['data'] as List)
              .map((item) => WorkoutPlan.fromJson(item))
              .toList(),
    );
  }
}

class WorkoutPlan {
  final String id;
  final String title;
  final String days;
  final String forwhy;
  final String workOutTime;

  WorkoutPlan({
    required this.id,
    required this.title,
    required this.days,
    required this.forwhy,
    required this.workOutTime,
  });

  factory WorkoutPlan.fromJson(Map<String, dynamic> json) {
    return WorkoutPlan(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      days: json['days'] ?? '',
      forwhy: json['forwhy'] ?? '',
      workOutTime: json['workOutTime'] ?? '',
    );
  }
}
