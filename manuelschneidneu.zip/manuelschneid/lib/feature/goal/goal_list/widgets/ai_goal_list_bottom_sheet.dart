import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/image_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_dropdown_widget.dart'
    show CustomDropdown;
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/goal/goal_list/controller/goal_controller.dart'
    show GoalController;

Widget _buildBottomSheetContent({
  required BuildContext context,
  required String specificQuestion,
  required Widget inputWidget,
  required String buttonText,
  required VoidCallback onButtonPressed,
  required String imagePath,
}) {
  return Padding(
    padding: MediaQuery.of(context).viewInsets,
    child: SingleChildScrollView(
      child: IntrinsicHeight(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "customize_your_training_plan_based_on_your_fitness_level".tr,
                textAlign: TextAlign.center,
                style: globalTextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 20),
              Image.asset(imagePath, width: 216, height: 214),
              Container(
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(40)),
                ),
                child: Text(
                  specificQuestion,
                  textAlign: TextAlign.center,
                  style: globalTextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
              SizedBox(height: 10),
              inputWidget,
              SizedBox(height: 50),
              CustomButtom(
                contentPadding: 16,
                text: buttonText,
                ontap: onButtonPressed,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

void showFitnessPlanInputBottomSheet(BuildContext context) {
  final GoalController controller = Get.find<GoalController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          //specificQuestion: "Write here your fitness plan ?",
          specificQuestion: "write_your_fitness_plan_here".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: TextField(
            controller: controller.fitnessPlanController,
            style: globalTextStyle(color: Colors.white),
            decoration: InputDecoration(
              contentPadding: EdgeInsets.all(20),
              hintText: "write_here".tr,
              hintStyle: globalTextStyle(color: Colors.white54),
              border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white38),
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
            ),
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context);
            showFitnessLevelBottomSheet(context);
          },
        ),
  );
}

void showFitnessLevelBottomSheet(BuildContext context) {
  final GoalController controller = Get.find<GoalController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "What is your current fitness level?",
          specificQuestion: "what_is_your_current_fitness_level".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            items: ["beginner".tr, "intermediate".tr, "advanced".tr],
            hintText: "beginner/intermediate/advanced".tr,
            controller: controller.fitnessLevelController,
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context);
            showTrainingGoalsBottomSheet(context);
          },
        ),
  );
}

// --- Step 3: Primary Training Goals Selection ---
void showTrainingGoalsBottomSheet(BuildContext context) {
  final GoalController controller = Get.find<GoalController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "What are your primary training goals?",
          specificQuestion: "what_are_your_primary_training_goals".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            // items: ["Strength", "Endurance", "Technique"],
            // hintText: "Strength/Endurance/Technique",
            items: ["strength".tr, "endurance".tr, "technique".tr],
            hintText: "strength/endurance/technique".tr,
            controller: controller.primaryGoalsController,
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context);
            showTrainingDaysBottomSheet(context);
          },
        ),
  );
}

// --- Step 4: Training Days Selection ---
void showTrainingDaysBottomSheet(BuildContext context) {
  final GoalController controller = Get.find<GoalController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "How many days per week do you train?",
          specificQuestion: "how_many_days_per_week_do_you_train".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            items: [
              "0_days".tr,
              "1_days".tr,
              "2_days".tr,
              "3_days".tr,
              "4_days".tr,
              "5_days".tr,
              "6_days".tr,
              "7_days".tr,
            ],
            hintText: "0_days".tr,
            controller: controller.trainingDaysController,
          ),
          buttonText: "generate_goal".tr,
          onButtonPressed: () {
            controller.postGoal();
          },
        ),
  );
}
