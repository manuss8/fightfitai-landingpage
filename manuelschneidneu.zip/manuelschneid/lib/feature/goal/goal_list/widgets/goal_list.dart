import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/goal/goal_details/view/goal_details_view.dart';
import 'package:manuelschneid/feature/goal/containers/goal_list_containers.dart';
import 'package:manuelschneid/feature/goal/goal_list/controller/goal_controller.dart';

class GoalList extends StatelessWidget {
  GoalList({super.key});

  final GoalController controller = Get.find<GoalController>();

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.isLoading.value) {
        return Center(child: CircularProgressIndicator());
      }

      final plans = controller.goalList;

      if (plans.isEmpty) {
        //coustom user show message..
        return Column(
          children: [
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  spacing: 12,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Anfänger Stärke Aszendent",
                      style: globalTextStyle(
                        color: AppColors.primaryColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),

                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        GoalListContainers(text: "05 tage"),
                        GoalListContainers(text: "Stärke aufbauen"),
                        GoalListContainers(text: "40-50 minuten"),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      }
      return ListView.builder(
        itemCount: controller.goalList.length,
        padding: EdgeInsets.zero,
        itemBuilder: (context, index) {
          var goal = controller.goalList[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: GestureDetector(
              onTap: () {
                Get.to(() => GoalDetailsView(), arguments: goal.id);
              },
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.04),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    spacing: 12,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        goal.title,
                        style: globalTextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          GoalListContainers(text: goal.days),
                          GoalListContainers(text: goal.forwhy),
                          GoalListContainers(text: goal.workOutTime),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    });
  }
}
