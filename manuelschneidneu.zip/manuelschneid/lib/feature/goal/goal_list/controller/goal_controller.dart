import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/feature/goal/goal_list/model/goal_model.dart';

class GoalController extends GetxController {
  var selectedContainer = 1.obs;
  RxBool isLoading = false.obs;
  void selectContainer(int containerId) {
    selectedContainer.value = containerId;
    if (kDebugMode) {
      print("The selected container's value is ${selectedContainer.value}");
    }
  }

  @override
  void onInit() {
    super.onInit();
    getGoal();
  }

  var titleController = TextEditingController();
  var dateController = TextEditingController();
  var workoutTypeController = TextEditingController();
  var workoutTimer = TextEditingController();
  var workoutTimer2 = TextEditingController();
  var aiq1Controller = TextEditingController();

  final TextEditingController fitnessPlanController = TextEditingController();
  final TextEditingController fitnessLevelController = TextEditingController();
  final TextEditingController primaryGoalsController = TextEditingController();
  final TextEditingController trainingDaysController = TextEditingController();

  void generateAiGoal() {
    final plan = fitnessPlanController.text;
    final level = fitnessLevelController.text;
    final goals = primaryGoalsController.text;
    final days = trainingDaysController.text;

    Get.snackbar(
      "goal_data".tr,
      "${"plan".tr}: $plan, ${"level".tr}: $level, ${"goals".tr}: $goals, ${"days".tr}: $days",
    );
  }

  Future<void> postGoal() async {
    var token = await SharePref.getSavedToken();

    Get.dialog(
      Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            LoadingAnimationWidget.staggeredDotsWave(
              color: Colors.white,
              size: 60,
            ),
            const SizedBox(height: 16),
            Text(
              "ai_is_generating_your_routine".tr,
              style: TextStyle(color: Colors.white),
            ),
          ],
        ),
      ),
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.6),
    );

    try {
      final response = await http.post(
        Uri.parse("${Urls.baseUrl}/workout"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ?? "",
        },
        body: json.encode([
          {
            "questions": "Write here your fitness plan?",
            "answare": fitnessPlanController.text,
          },
          {
            "questions": "What is your current fitness level?",
            "answare": fitnessLevelController.text,
          },
          {
            "questions": "What are your primary training goals?",
            "answare": primaryGoalsController.text,
          },
          {
            "questions": "How many days per week do you train?",
            "answare": trainingDaysController.text,
          },
        ]),
      );

      if (response.statusCode == 201) {
        Get.back();
        Get.back();
        fitnessPlanController.clear();
        fitnessLevelController.clear();
        primaryGoalsController.clear();
        trainingDaysController.clear();
        Get.snackbar(
          "success".tr,
          "goal_created_successfully".tr,
          backgroundColor: AppColors.primaryColor,
          colorText: Colors.white,
        );

        getGoal();
      } else {
        Get.back();
        Get.snackbar(
          "error".tr,
          "failed_to_create_goal".tr,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      Get.back();
      print(e);
      Get.snackbar(
        "error".tr,
        "something_went_wrong".tr,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      EasyLoading.dismiss();
    }
  }

  final RxList<WorkoutPlan> goalList = <WorkoutPlan>[].obs;

  Future<void> getGoal() async {
    isLoading.value = true;
    var token = await SharePref.getSavedToken();

    try {
      final response = await http.get(
        Uri.parse("${Urls.baseUrl}/workout"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ?? "",
        },
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);

        final workoutPlanResponse = WorkoutPlanResponse.fromJson(jsonData);

        goalList.clear();
        goalList.addAll(workoutPlanResponse.data);

        print('Goal list updated. Total items: ${goalList.length}');
      } else {
        print(
          "Failed to fetch workout plans. Status code: ${response.statusCode}",
        );
      }
    } catch (e) {
      print("Error fetching workout plans: $e");
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    super.onClose();
    fitnessPlanController.dispose();
    fitnessLevelController.dispose();
    primaryGoalsController.dispose();
    trainingDaysController.dispose();
  }
}
