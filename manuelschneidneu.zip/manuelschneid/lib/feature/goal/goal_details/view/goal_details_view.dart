import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart' show AppColors;
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/goal/goal_details/controller/goal_details_controller.dart';
import 'package:url_launcher/url_launcher.dart';

class GoalDetailsView extends StatelessWidget {
  GoalDetailsView({super.key});

  final GoalDetailsController controller = Get.put(GoalDetailsController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final workoutDetail = controller.selectedWorkoutDetail.value;
      return Scaffold(
        backgroundColor: AppColors.appBackgroundColor,
        appBar: AppBar(
          backgroundColor: AppColors.appBackgroundColor,
          title: Text(
            workoutDetail?.title ?? "",
            style: globalTextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFFF1F2F6),
            ),
          ),
          centerTitle: true,
          leading: Padding(
            padding: EdgeInsets.only(left: 20),
            child: GestureDetector(
              onTap: () {
                Get.back();
              },
              child: CircleAvatar(
                radius: 21,
                backgroundColor: Colors.white.withOpacity(0.1),
                child: Center(
                  child: Icon(
                    Icons.arrow_back_ios_new,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              ),
            ),
          ),
        ),
        body: Obx(() {
          final detail = controller.selectedWorkoutDetail.value;

          if (detail == null) {
            return const Center(child: CircularProgressIndicator());
          }

          final workoutList = detail.workOutList;
          final references = detail.references;

          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            children: [
              // References section
              if (references.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 5),
                      ...List.generate(workoutList.length, (index) {
                        final workout = workoutList[index];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.04),
                            borderRadius: BorderRadius.circular(12),
                            border:
                                controller.isExpandedList[index]
                                    ? Border.all(
                                      color: Colors.transparent,
                                      width: 0,
                                    )
                                    : null,
                          ),
                          child: ExpansionTile(
                            initiallyExpanded: controller.isExpandedList[index],
                            tilePadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 5,
                            ),
                            childrenPadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 20,
                            ),
                            collapsedBackgroundColor: Colors.transparent,
                            backgroundColor: Colors.transparent,
                            iconColor: Colors.white,
                            collapsedIconColor: Colors.white,
                            onExpansionChanged: (isExpanded) {
                              controller.toggleExpanded(index);
                            },
                            title: Text(
                              workout.type,
                              style: globalTextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color:
                                    controller.isExpandedList[index]
                                        ? AppColors.primaryColor
                                        : Colors.white,
                              ),
                            ),
                            children: <Widget>[
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      workout.what,
                                      style: globalTextStyle(
                                        fontSize: 14,
                                        color: Colors.white70,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      "${"example".tr}: ${workout.example}",
                                      style: globalTextStyle(
                                        fontSize: 14,
                                        color: Colors.white70,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      "${"benefit".tr}: ${workout.benefit}",
                                      style: globalTextStyle(
                                        fontSize: 14,
                                        color: Colors.white70,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                      Text(
                        "references".tr,
                        style: globalTextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      Wrap(
                        children:
                            references.trim().isEmpty
                                ? [
                                  Text(
                                    'No reference available',
                                    style: globalTextStyle(
                                      fontSize: 14,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ]
                                : references
                                    .split(',')
                                    .map(
                                      (ref) => GestureDetector(
                                        onTap: () async {
                                          final url = ref.trim();
                                          if (await canLaunchUrl(
                                            Uri.parse(url),
                                          )) {
                                            await launchUrl(Uri.parse(url));
                                          }
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            right: 8,
                                            bottom: 5,
                                          ),
                                          child: Text(
                                            ref.trim(),
                                            style: globalTextStyle(
                                              fontSize: 14,
                                              color: Colors.blueAccent,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList(),
                      ),
                    ],
                  ),
                ),
            ],
          );
        }),
      );
    });
  }
}
