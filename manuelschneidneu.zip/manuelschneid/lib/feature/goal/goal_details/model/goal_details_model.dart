class WorkoutDetailResponse {
  final bool success;
  final String message;
  final WorkoutDetail data;

  WorkoutDetailResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  factory WorkoutDetailResponse.fromJson(Map<String, dynamic> json) {
    return WorkoutDetailResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data: WorkoutDetail.fromJson(json['data']),
    );
  }
}

class WorkoutDetail {
  final String id;
  final String title;
  final String days;
  final String forwhy;
  final String workOutTime;
  final String references; // new field
  final List<WorkoutType> workOutList;
  final String createdAt;
  final String updatedAt;

  WorkoutDetail({
    required this.id,
    required this.title,
    required this.days,
    required this.forwhy,
    required this.workOutTime,
    required this.references, // new field
    required this.workOutList,
    required this.createdAt,
    required this.updatedAt,
  });

  factory WorkoutDetail.fromJson(Map<String, dynamic> json) {
    return WorkoutDetail(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      days: json['days'] ?? '',
      forwhy: json['forwhy'] ?? '',
      workOutTime: json['workOutTime'] ?? '',
      references: json['references'] ?? '', // parse new field
      workOutList:
          (json['workOutList'] as List)
              .map((item) => WorkoutType.fromJson(item))
              .toList(),
      createdAt: json['createdAt'] ?? '',
      updatedAt: json['updatedAt'] ?? '',
    );
  }
}

class WorkoutType {
  final String type;
  final String what;
  final String example;
  final String benefit;

  WorkoutType({
    required this.type,
    required this.what,
    required this.example,
    required this.benefit,
  });

  factory WorkoutType.fromJson(Map<String, dynamic> json) {
    return WorkoutType(
      type: json['type'] ?? '',
      what: json['what'] ?? '',
      example: json['example'] ?? '',
      benefit: json['benefit'] ?? '',
    );
  }
}
