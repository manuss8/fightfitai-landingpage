import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/const/image_path.dart' show ImagePath;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/core/style/global_text_style.dart'
    show globalTextStyle;
import 'package:manuelschneid/feature/bottom_navbar/view/bottom_navbar_view.dart';
import 'package:manuelschneid/feature/goal/goal_details/model/goal_details_model.dart';

class GoalDetailsController extends GetxController {
  // var text =
  //     "Lorem ipsum dolor sit amet consectetur. Commodo etiam id facilisis id arcu amet justo dolor tellus. Dui feugiat id duis leo dolor gravida in. Integer ut eu cras id at. Id a felis diam ultrices urna tortor morbi lacus. Vitae nunc risus pretium nec pellentesque. Ac et tempus risus aenean sed ac suspendisse pharetra. Volutpat justo eu sodales tellus enim volutpat purus. Adipiscing feugiat porttitor volutpat facilisis tincidunt nunc ornare. Cursus diam fermentum urna a tortor laoreet. Blandit eget vestibulum lectus felis dui. Enim odio at ultricies quam nisi. Sit velit sed velit sollicitudin dui a scelerisque diam ultricies.";

  RxInt countdownTime = 300.obs;
  int totalTime = 300;

  RxList<bool> isExpandedList = RxList<bool>([]);

  void toggleExpanded(int index) {
    if (index >= 0 && index < isExpandedList.length) {
      isExpandedList[index] = !isExpandedList[index];
      isExpandedList.refresh();
    }
  }

  var id = '';
  @override
  void onInit() {
    super.onInit();
    id = Get.arguments;
    print("ID: $id");
    getGoalDetails(id);
  }

  final Rxn<WorkoutDetail> selectedWorkoutDetail = Rxn<WorkoutDetail>();

  Future<void> getGoalDetails(String id) async {
    var token = await SharePref.getSavedToken();

    try {
      final response = await http.get(
        Uri.parse("${Urls.baseUrl}/workout/$id"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ?? "",
        },
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final detailResponse = WorkoutDetailResponse.fromJson(jsonData);

        selectedWorkoutDetail.value = detailResponse.data;
        // ✅ Dynamically initialize isExpandedList
        final workoutCount = detailResponse.data.workOutList.length;
        isExpandedList.value = List.generate(workoutCount, (_) => true);

        print("Fetched workout detail: ${detailResponse.data.title}");
      } else {
        print(
          "Failed to fetch workout details. Status: ${response.statusCode}",
        );
      }
    } catch (e) {
      print("Error fetching workout details: $e");
    }
  }

  String getFormattedTime() {
    int minutes = countdownTime.value ~/ 60;
    int seconds = countdownTime.value % 60;
    return "$minutes:${seconds.toString().padLeft(2, '0')}";
  }

  double getProgress() {
    return (totalTime - countdownTime.value) / totalTime;
  }

  void showCompletionDialog(BuildContext context) {
    Get.dialog(
      AlertDialog(
        backgroundColor: Colors.transparent,
        content: Container(
          width: MediaQuery.of(context).size.width * 0.9,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(ImagePath.alertImage),
              fit: BoxFit.cover,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "congratulations_you_finished_this_challenge_earn_50_points".tr,
                style: globalTextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              Image.asset(ImagePath.badge, width: 295, height: 229),
              SizedBox(height: 13),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.offAll(() => BottomNavbarView());
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.27,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white.withValues(alpha: 0.4),
                        border: Border.all(color: Colors.white),
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(ImagePath.sunflower, width: 25),
                            SizedBox(width: 5),
                            Text(
                              "50_points".tr,
                              style: globalTextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.27,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                        border: Border.all(color: Colors.white),
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Center(
                          child: Text(
                            "done".tr,
                            style: globalTextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
