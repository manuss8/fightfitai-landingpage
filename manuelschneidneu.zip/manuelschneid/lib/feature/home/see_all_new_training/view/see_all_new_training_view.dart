import 'dart:math';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart' show AppColors;
import 'package:manuelschneid/core/global_widegts/course_sub_dialog.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/course_details/view/category_details_view.dart';
import 'package:manuelschneid/feature/home/home_data/controller/home_controller.dart';
import 'package:manuelschneid/feature/home/see_all_training_category/widgets/see_all_custom_textfield.dart';
import 'package:manuelschneid/feature/user_profile/view/upgrade_pro_view.dart';
import 'package:shimmer/shimmer.dart';

class SeeAllNewTrainingView extends StatelessWidget {
  SeeAllNewTrainingView({super.key});

  final HomeController controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
              child: Center(
                child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
              ),
            ),
          ),
        ),
        title: Text(
          "new_training".tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            SizedBox(height: 20),

            //Search
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: SeeAllCustomTextfield(
                controller: controller.searchController,
                onChanged: (value) {
                  controller.searchByCategoryName(value);
                },
                hintText: "search".tr,
              ),
            ),

            SizedBox(height: 20),
            // course list......
            Obx(() {
              if (controller.searchNewCourseList.isEmpty) {
                return Expanded(
                  child: Center(
                    child: Text(
                      "no_course_data_found".tr,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                );
              }
              return Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.zero,
                  scrollDirection: Axis.vertical,
                  itemCount: min(10, controller.searchNewCourseList.length),
                  itemBuilder: (BuildContext context, int index) {
                    final course = controller.searchNewCourseList[index];
                    return Padding(
                      padding: const EdgeInsets.only(
                        left: 10,
                        right: 15.0,
                        bottom: 20,
                      ),
                      child: GestureDetector(
                        onTap: () {
                          if (course.courseType == "PAID" &&
                              course.isPayment == false) {
                            Get.dialog(
                              CourseSubDialog(
                                onConfirm: () {
                                  Get.back();
                                  Get.to(() => UpgradeProView());
                                },
                                onCancel: () {
                                  Get.back();
                                },
                              ),
                            );
                            return;
                          }
                          Get.to(
                            () => CategoryDetailsView(),
                            arguments: {'courseId': course.id},
                          );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(22),
                          child: Stack(
                            children: [
                              CachedNetworkImage(
                                imageUrl: course.thumbnail,
                                width: double.infinity,
                                height: 204,
                                fit: BoxFit.cover,
                                placeholder:
                                    (context, url) => Shimmer.fromColors(
                                      baseColor: Colors.grey.shade800,
                                      highlightColor: Colors.grey.shade700,
                                      child: Container(
                                        width: double.infinity,
                                        height: 204,
                                        color: Colors.grey,
                                      ),
                                    ),
                                errorWidget:
                                    (context, url, error) => Container(
                                      width: double.infinity,
                                      height: 204,
                                      color: Colors.grey.shade900,
                                      child: Icon(
                                        Icons.broken_image,
                                        color: Colors.red,
                                      ),
                                    ),
                              ),
                              Positioned.fill(
                                child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          SizedBox(
                                            child:
                                                course.courseType == "PAID" &&
                                                        course.isPayment ==
                                                            false
                                                    ? const Icon(
                                                      Icons.lock,
                                                      color: Colors.grey,
                                                      size: 24,
                                                    )
                                                    : const SizedBox.shrink(),
                                          ),

                                          const Spacer(),
                                          Align(
                                            alignment: Alignment.topRight,
                                            child: Container(
                                              width: 80,
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(
                                                  alpha: 0.06,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(52),
                                                border: Border.all(
                                                  color: Colors.white
                                                      .withValues(alpha: 0.05),
                                                ),
                                              ),
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                  vertical: 4,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      Icons.star,
                                                      color:
                                                          AppColors
                                                              .primaryColor,
                                                    ),
                                                    SizedBox(width: 5),
                                                    Text(
                                                      course.avgRating
                                                          .toString(),
                                                      style: globalTextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Spacer(),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              course.title,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: globalTextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: 10),
                                          Container(
                                            width: 82,
                                            decoration: BoxDecoration(
                                              color: AppColors.primaryColor,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Center(
                                              child: Padding(
                                                padding: const EdgeInsets.all(
                                                  8.0,
                                                ),
                                                child: Text(
                                                  course.category,
                                                  maxLines: 2,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: globalTextStyle(
                                                    color: Colors.black,
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
