import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/course_sub_dialog.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/course_details/view/category_details_view.dart';
import 'package:manuelschneid/feature/home/home_data/controller/home_controller.dart';
import 'package:manuelschneid/feature/home/see_all_training_category/widgets/see_all_custom_textfield.dart';
import 'package:manuelschneid/feature/user_profile/view/upgrade_pro_view.dart';
import 'package:shimmer/shimmer.dart';

class SeeAllTrainingCategoryView extends StatelessWidget {
  SeeAllTrainingCategoryView({super.key});

  final HomeController controller = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 70),
          //Search
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: SeeAllCustomTextfield(
              controller: controller.searchControllerTraning,
              onChanged: (value) {
                controller.searchCourseByTitle(value);
              },
              hintText: "search".tr,
            ),
          ),
          SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Text(
              "training_category".tr,
              style: globalTextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(height: 20),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Obx(() {
              if (controller.isLoader.value) {
                // Show shimmer placeholders
                return Row(
                  children: List.generate(5, (index) {
                    return Container(
                      width: 100,
                      height: 40,
                      margin: EdgeInsets.only(left: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(83),
                        color: Colors.grey.shade700,
                      ),
                      child: Shimmer.fromColors(
                        baseColor: Colors.grey.shade700,
                        highlightColor: Colors.grey.shade500,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            vertical: 7,
                            horizontal: 20,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(83),
                          ),
                        ),
                      ),
                    );
                  }),
                );
              }

              // Actual tabs
              return Row(
                children: List.generate(controller.categoriesList.length, (
                  index,
                ) {
                  bool isSelected = controller.selectedIndex.value == index;
                  return GestureDetector(
                    onTap: () => controller.selectTab(index),
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        vertical: 7,
                        horizontal: 20,
                      ),
                      margin: EdgeInsets.only(left: 20),
                      decoration: BoxDecoration(
                        color:
                            isSelected
                                ? AppColors.primaryColor
                                : Color(0xFF313131),
                        borderRadius: BorderRadius.circular(83),
                      ),
                      child: Text(
                        //controller.categoriesList[index].title,
                        controller.categoriesList[index].title == "All"
                            ? "all".tr
                            : controller.categoriesList[index].title,
                        style: TextStyle(
                          color: isSelected ? Colors.black : Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                }),
              );
            }),
          ),
          SizedBox(height: 20),

          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                // Show shimmer loading
                return ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(
                        left: 15,
                        right: 15,
                        bottom: 20,
                      ),
                      child: Shimmer.fromColors(
                        baseColor: Colors.grey.shade700,
                        highlightColor: Colors.grey.shade600,
                        child: Container(
                          width: double.infinity,
                          height: 204,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(22),
                          ),
                        ),
                      ),
                    );
                  },
                );
              }

              if (controller.filteredCourseList.isEmpty) {
                return Center(
                  child: Text(
                    "no_courses_available_for_this_category".tr,
                    style: TextStyle(color: Colors.grey),
                  ),
                );
              }

              return ListView.builder(
                padding: EdgeInsets.zero,
                scrollDirection: Axis.vertical,
                itemCount: controller.filteredCourseList.length,
                itemBuilder: (BuildContext context, int index) {
                  final course = controller.filteredCourseList[index];
                  return Padding(
                    padding: const EdgeInsets.only(
                      left: 15,
                      right: 15.0,
                      bottom: 20,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        if (course.courseType == "PAID" &&
                            course.isPayment == false) {
                          Get.dialog(
                            CourseSubDialog(
                              onConfirm: () {
                                Get.back();
                                Get.to(() => UpgradeProView());
                              },
                              onCancel: () {
                                Get.back();
                              },
                            ),
                          );
                          return;
                        }
                        Get.to(
                          () => CategoryDetailsView(),
                          arguments: {'courseId': course.id},
                        );
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(22),
                        child: Stack(
                          children: [
                            CachedNetworkImage(
                              imageUrl: course.thumbnail,
                              width: double.infinity,
                              height: 204,
                              fit: BoxFit.cover,
                              placeholder:
                                  (context, url) => Shimmer.fromColors(
                                    baseColor: Colors.grey.shade800,
                                    highlightColor: Colors.grey.shade700,
                                    child: Container(
                                      width: double.infinity,
                                      height: 204,
                                      color: Colors.grey,
                                    ),
                                  ),
                              errorWidget:
                                  (context, url, error) => Container(
                                    width: double.infinity,
                                    height: 204,
                                    color: Colors.grey.shade900,
                                    child: Icon(
                                      Icons.broken_image,
                                      color: Colors.red,
                                    ),
                                  ),
                            ),
                            Positioned.fill(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        SizedBox(
                                          child:
                                              course.courseType == "PAID" &&
                                                      course.isPayment == false
                                                  ? const Icon(
                                                    Icons.lock,
                                                    color: Colors.grey,
                                                    size: 24,
                                                  )
                                                  : const SizedBox.shrink(),
                                        ),

                                        const Spacer(),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Container(
                                            width: 80,
                                            decoration: BoxDecoration(
                                              color: Colors.white.withOpacity(
                                                0.06,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(52),
                                              border: Border.all(
                                                color: Colors.white.withOpacity(
                                                  0.05,
                                                ),
                                              ),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 4,
                                                  ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Icon(
                                                    Icons.star,
                                                    color:
                                                        AppColors.primaryColor,
                                                  ),
                                                  const SizedBox(width: 5),
                                                  Text(
                                                    course.avgRating.toString(),
                                                    style: globalTextStyle(
                                                      color: Colors.white,
                                                      fontSize: 12,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Spacer(),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            course.title,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: globalTextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        Container(
                                          width: 82,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryColor,
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.all(
                                                8.0,
                                              ),
                                              child: Text(
                                                course.category,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: globalTextStyle(
                                                  color: Colors.black,
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
          SizedBox(height: 90),
        ],
      ),
    );
  }
}
