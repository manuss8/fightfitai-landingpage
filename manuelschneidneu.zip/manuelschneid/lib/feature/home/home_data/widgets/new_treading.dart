import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:manuelschneid/feature/course_details/view/category_details_view.dart'
    show CategoryDetailsView;
import 'package:manuelschneid/feature/home/home_data/controller/home_controller.dart'
    show HomeController;
import 'package:manuelschneid/feature/home/see_all_new_training/view/see_all_new_training_view.dart';
import 'package:shimmer/shimmer.dart';

class NewTreading extends StatelessWidget {
  NewTreading({super.key});

  final HomeController controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Text(
                "new_training".tr,
                style: globalTextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Spacer(),
              GestureDetector(
                onTap: () {
                  Get.to(
                    () => SeeAllNewTrainingView(),
                    arguments: controller.courseList.take(10).toList(),
                  );
                },
                child: Text(
                  "see_all".tr,
                  style: globalTextStyle(
                    fontSize: 15,
                    color: AppColors.primaryColor,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 25),
        Obx(() {
          if (controller.isLoading.value) {
            return SizedBox(
              height: 200,
              child: CarouselSlider(
                options: CarouselOptions(
                  height: 200,
                  enlargeCenterPage: true,
                  viewportFraction: 0.8,
                ),
                items: List.generate(4, (index) {
                  return Builder(
                    builder:
                        (context) => Shimmer.fromColors(
                          baseColor: Colors.grey.shade700,
                          highlightColor: Colors.grey.shade600,
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.85,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade800,
                              borderRadius: BorderRadius.circular(22),
                            ),
                          ),
                        ),
                  );
                }),
              ),
            );
          }
          return CarouselSlider(
            options: CarouselOptions(
              height: 200,
              autoPlay: false,
              enlargeCenterPage: true,
              viewportFraction: 0.8,
            ),
            items:
                controller.courseList.take(10).map((item) {
                  return Builder(
                    builder: (BuildContext context) {
                      return GestureDetector(
                        onTap: () {
                          // if (item.courseType == "PAID" &&
                          //     item.isPayment == false) {
                          //   Get.dialog(
                          //     CourseSubDialog(
                          //       onConfirm: () {
                          //         Get.back();
                          //         Get.to(() => UpgradeProView());
                          //       },
                          //       onCancel: () {
                          //         Get.back();
                          //       },
                          //     ),
                          //   );
                          //   return;
                          // }
                          Get.to(
                            () => CategoryDetailsView(),
                            arguments: {'courseId': item.id},
                          );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(22),
                          child: Stack(
                            children: [
                              CachedNetworkImage(
                                imageUrl: item.thumbnail,
                                width: MediaQuery.of(context).size.width * 0.85,
                                height: 204,
                                fit: BoxFit.cover,
                                placeholder:
                                    (context, url) => Shimmer.fromColors(
                                      baseColor: Colors.grey.shade800,
                                      highlightColor: Colors.grey.shade700,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                            0.85,
                                        height: 204,
                                        color: Colors.grey,
                                      ),
                                    ),
                                errorWidget:
                                    (context, url, error) => Container(
                                      width:
                                          MediaQuery.of(context).size.width *
                                          0.85,
                                      height: 204,
                                      color: Colors.grey.shade900,
                                      child: Icon(
                                        Icons.broken_image,
                                        color: Colors.red,
                                      ),
                                    ),
                              ),
                              Positioned.fill(
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          // SizedBox(
                                          //   child:
                                          //       item.courseType == "PAID" &&
                                          //               item.isPayment == false
                                          //           ? const Icon(
                                          //             Icons.lock,
                                          //             color: Colors.grey,
                                          //             size: 24,
                                          //           )
                                          //           : const SizedBox.shrink(),
                                          // ),
                                          const Spacer(),
                                          Align(
                                            alignment: Alignment.topRight,
                                            child: Container(
                                              width: 80,
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(
                                                  alpha: 0.06,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(52),
                                                border: Border.all(
                                                  color: Colors.white
                                                      .withValues(alpha: 0.05),
                                                ),
                                              ),
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                  vertical: 4,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      Icons.star,
                                                      color:
                                                          AppColors
                                                              .primaryColor,
                                                    ),
                                                    SizedBox(width: 5),
                                                    Text(
                                                      item.avgRating.toString(),
                                                      style: globalTextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Spacer(),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              item.title,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: globalTextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 18,
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: 10),
                                          Container(
                                            width: 82,
                                            decoration: BoxDecoration(
                                              color: AppColors.primaryColor,
                                              borderRadius:
                                                  BorderRadius.circular(52),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(
                                                8.0,
                                              ),
                                              child: Center(
                                                child: Text(
                                                  item.category,
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: globalTextStyle(
                                                    color: Colors.black,
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                }).toList(),
          );
        }),
      ],
    );
  }
}
