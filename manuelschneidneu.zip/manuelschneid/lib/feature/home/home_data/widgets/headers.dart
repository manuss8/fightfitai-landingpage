import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/const/image_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/home/home_data/controller/home_controller.dart';
import 'package:manuelschneid/feature/notification/controller/notification_controller.dart';
import 'package:manuelschneid/feature/notification/view/notification_screen.dart';
import 'package:manuelschneid/feature/user_profile/controller/profile_controller.dart';
import 'package:manuelschneid/feature/user_profile/view/profile_view.dart';

class Headers extends StatelessWidget {
  Headers({super.key});
  final UserProfileController userProfileController = Get.put(
    UserProfileController(),
  );
  final HomeController controller = Get.find<HomeController>();
  final NotificationController notificationController = Get.put(
    NotificationController(),
  );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 70, left: 24, right: 24),
      child: Row(
        children: [
          Obx(
            () => GestureDetector(
              onTap: () {
                Get.to(() => UserProfileView());
              },
              child: CircleAvatar(
                radius: 25,
                backgroundImage:
                    userProfileController.profileImage.value != null
                        ? FileImage(userProfileController.profileImage.value!)
                        : (userProfileController.networkImage.value != null &&
                            userProfileController
                                .networkImage
                                .value!
                                .isNotEmpty)
                        ? NetworkImage(
                          userProfileController.networkImage.value!,
                        )
                        : AssetImage(IconsPath.profileAvater) as ImageProvider,
              ),
            ),
          ),
          SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "welcome_back".tr,
                style: globalTextStyle(color: Color(0xFF7E7D7C)),
              ),
              Obx(
                () => Text(
                  userProfileController.userProfile.value?.data.userName ??
                      "N/A",
                  style: globalTextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          Spacer(),

          GestureDetector(
            onTap: () {
              Get.to(() => NotificationScreen());
            },
            child: Stack(
              children: [
                Image.asset(ImagePath.notification, width: 50),
                Obx(() {
                  int unreadCount =
                      notificationController.notifications
                          .where((n) => !n.isRead)
                          .length;

                  if (unreadCount == 0) return SizedBox();

                  return Positioned(
                    left: 30,
                    child: CircleAvatar(
                      radius: 10,
                      backgroundColor: AppColors.primaryColor,
                      child: Center(
                        child: Text(
                          unreadCount.toString(),
                          style: globalTextStyle(
                            color: Colors.black,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
