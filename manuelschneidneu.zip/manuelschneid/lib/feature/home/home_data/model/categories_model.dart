class UserCategoriesModel {
  final bool success;
  final String message;
  final List<CategoryData> data;

  UserCategoriesModel({
    required this.success,
    required this.message,
    required this.data,
  });

  factory UserCategoriesModel.fromJson(Map<String, dynamic> json) {
    return UserCategoriesModel(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data:
          (json['data'] as List)
              .map((item) => CategoryData.fromJson(item))
              .toList(),
    );
  }
}

class CategoryData {
  final String id;
  final String title;
  final String createdAt;
  final String updatedAt;

  CategoryData({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CategoryData.fromJson(Map<String, dynamic> json) {
    return CategoryData(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      createdAt: json['createdAt'] ?? '',
      updatedAt: json['updatedAt'] ?? '',
    );
  }
}
