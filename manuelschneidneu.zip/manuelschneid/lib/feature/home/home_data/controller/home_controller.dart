import 'dart:convert';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/home/home_data/model/categories_model.dart';
import 'package:manuelschneid/feature/home/home_data/model/course_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeController extends GetxController {
  final TextEditingController searchController = TextEditingController();
  final TextEditingController searchControllerTraning = TextEditingController();
  RxList<CategoryData> categoriesList = <CategoryData>[].obs;
  RxList<CourseData> courseList = <CourseData>[].obs;
  RxList<CourseData> filteredCourseList = <CourseData>[].obs;
  RxList<CourseData> searchNewCourseList = <CourseData>[].obs;
  RxBool isLoading = false.obs;
  RxBool isLoader = false.obs;

  var selectedIndex = 0.obs;

  @override
  void onInit() {
    super.onInit();
    getCategoryList();
    getCourseList();
  }

  /// 🔘 Select a category tab
  void selectTab(int index) {
    selectedIndex.value = index;
    searchController.clear();
    final selectedCategory = categoriesList[index].title;
    filterCourseByCategory(selectedCategory);
  }

  // get categories api call
  Future<void> getCategoryList() async {
    final url = Urls.getcategory;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');
    isLoader.value = true;
    await Future.delayed(Duration(seconds: 2));

    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response Category URL: $url');
      log('Response CategoryStatus code: ${response.statusCode}');
      log('Response Category body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);

        if (decodedData['data'] != null) {
          UserCategoriesModel categoriesModel = UserCategoriesModel.fromJson(
            decodedData,
          );
          categoriesList.value = categoriesModel.data;
          // Add "All" category at the beginning
          categoriesList.value = [
            CategoryData(title: "All", id: "all", createdAt: "", updatedAt: ""),
            ...categoriesModel.data,
          ];
        } else {
          EasyLoading.showError("no_category_data_found".tr);
        }
      } else {
        EasyLoading.showError("failed_to_get_category_data".tr);
        if (kDebugMode) {
          print('Failed to get category data!');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      isLoader.value = false;
      EasyLoading.dismiss();
    }
  }

  // get course list method........
  Future<void> getCourseList() async {
    final url = Urls.getcourse;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');
    isLoading.value = true;
    await Future.delayed(Duration(seconds: 2));

    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response Category URL: $url');
      log('Response CategoryStatus code: ${response.statusCode}');
      log('Response Category body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);

        if (decodedData['data'] != null) {
          List<CourseData> courses =
              (decodedData['data'] as List)
                  .map((item) => CourseData.fromJson(item))
                  .toList();
          courseList.value = courses;
          // Show all initially
          filterCourseByCategory("All");
          // search course
          searchNewCourseList.assignAll(courses);
        } else {
          EasyLoading.showError("no_course_data_found".tr);
        }
      } else {
        EasyLoading.showError("failed_to_get_course_data".tr);
        if (kDebugMode) {
          print('Failed to get category data!');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      isLoading.value = false;
      EasyLoading.dismiss();
    }
  }

  //Filter course by category
  void filterCourseByCategory(String category) {
    if (category == "All") {
      filteredCourseList.value = courseList;
    } else {
      filteredCourseList.value =
          courseList.where((course) => course.category == category).toList();
    }
  }

  // search method......
  void searchByCategoryName(String query) {
    if (query.isEmpty) {
      searchNewCourseList.assignAll(courseList);
    } else {
      final result =
          courseList
              .where(
                (course) =>
                    course.title.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
      searchNewCourseList.value = result;
    }
  }

  void clearSearch() {
    searchController.clear();
    searchNewCourseList.assignAll(courseList);
  }

  // training screen search...
  void searchCourseByTitle(String query) {
    final selectedCategory = categoriesList[selectedIndex.value].title;

    if (query.isEmpty) {
      filterCourseByCategory(selectedCategory);
    } else {
      final filtered =
          courseList.where((course) {
            final matchesTitle = course.title.toLowerCase().contains(
              query.toLowerCase(),
            );
            final matchesCategory =
                selectedCategory == "All"
                    ? true
                    : course.category.toLowerCase() ==
                        selectedCategory.toLowerCase();

            return matchesTitle && matchesCategory;
          }).toList();

      filteredCourseList.value = filtered;
    }
  }
}
