import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/route/app_route.dart';

class SplashScreenController extends GetxController {
  @override
  void onInit() {
    super.onInit();
    moveToNextScreen();
  }

  Future<void> moveToNextScreen() async {
    await Future.delayed(const Duration(seconds: 3));

    String? accessToken = await SharePref.getSavedToken();
    String? role = await SharePref.getSavedRole();
    if (kDebugMode) {
      print("role $role");
    }

    if (accessToken != null) {
      if (role == "USER") {
        Get.offAllNamed(AppRoute.bottomNavbarScreen);
      } else {
        Get.offAllNamed(AppRoute.adminProfile);
      }
    } else {
      Get.offAllNamed(AppRoute.signinScreen);
    }
  }
}
