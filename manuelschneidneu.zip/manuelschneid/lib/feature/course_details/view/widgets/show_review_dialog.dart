import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/image_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/course_details/controller/category_details_controller.dart';
import 'package:manuelschneid/feature/course_details/view/category_details_view.dart';

void showReviewDialog(BuildContext context) {
  final CategoryDetailsController controller = Get.put(
    CategoryDetailsController(),
  );

  Get.dialog(
    AlertDialog(
      backgroundColor: Colors.transparent,
      content: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: 300,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(ImagePath.alertImage),
            fit: BoxFit.cover,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "now_you_can_review_this_course".tr,
              style: globalTextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 30),

            // Rating Bar
            Obx(
              () => RatingBar.builder(
                initialRating: controller.userRating.value.toDouble(),
                minRating: 2,
                allowHalfRating: true,
                itemCount: 5,
                itemSize: 24,
                itemBuilder:
                    (context, _) => const Icon(Icons.star, color: Colors.amber),
                onRatingUpdate: (rating) {
                  controller.userRating.value = rating.toInt();
                },
              ),
            ),

            SizedBox(height: 100),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Get.back(); // Close dialog
                    Get.off(() => CategoryDetailsView());
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.27,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white.withValues(alpha: 0.4),
                      border: Border.all(color: Colors.white),
                    ),
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(ImagePath.sunflower, width: 25),
                          SizedBox(width: 2),
                          Text(
                            "cancel".tr,
                            style: globalTextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    controller.reviewsApiCall(
                      controller.courseDetails.value!.id,
                    );
                  },
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.27,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white.withValues(alpha: 0.4),
                      border: Border.all(color: Colors.white),
                    ),
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Center(
                        child: Text(
                          "submit".tr,
                          style: globalTextStyle(
                            color: Colors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
