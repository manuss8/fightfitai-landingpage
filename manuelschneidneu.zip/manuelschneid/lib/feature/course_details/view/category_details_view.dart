import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/course_details/view/widgets/category_details_shimmer.dart';
import 'package:manuelschneid/feature/course_details/view/widgets/description_container.dart'
    show DescriptionContainer;
import 'package:manuelschneid/feature/course_details/view/widgets/time_container.dart'
    show TimeContainer;
import 'package:video_player/video_player.dart';
import 'package:manuelschneid/feature/course_details/controller/category_details_controller.dart';

class CategoryDetailsView extends StatelessWidget {
  CategoryDetailsView({super.key});

  final courseId = Get.arguments['courseId'];

  final CategoryDetailsController controller = Get.put(
    CategoryDetailsController(),
  );

  @override
  Widget build(BuildContext context) {
    if (kDebugMode) {
      print("Course ID: $courseId");
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchCoursesDetails(courseId);
    });

    return Scaffold(
      backgroundColor: Colors.black87,
      body: Obx(() {
        final course = controller.courseDetails.value;

        if (course == null || controller.isLoading.value) {
          return const CategoryDetailsShimmer();
        }

        return SafeArea(
          bottom: false,
          child: SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: Stack(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height * 0.35,
                  child: Stack(
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (!controller.showCountdown.value) {
                            controller.toggleButtonVisibility();
                          }
                        },
                        child: SizedBox.expand(
                          child: AspectRatio(
                            aspectRatio:
                                controller.videoController.value.aspectRatio,
                            child: VideoPlayer(controller.videoController),
                          ),
                        ),
                      ),
                      Obx(() {
                        if (!controller.showCountdown.value &&
                            controller.showPlayButton.value) {
                          return Center(
                            child: Container(
                              height: 60,
                              width: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xffFFFFFF).withOpacity(0.06),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.06),
                                  width: 1,
                                ),
                              ),
                              child: Center(
                                child: IconButton(
                                  icon: Icon(
                                    controller.isPlaying.value
                                        ? Icons.pause
                                        : Icons.play_arrow,
                                    color: Colors.white,
                                    size: 40,
                                  ),
                                  onPressed: controller.toggleVideoPlayback,
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const SizedBox.shrink();
                        }
                      }),
                      Positioned(
                        top: 10,
                        left: 10,
                        child: Container(
                          height: 42,
                          width: 42,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            color: Color(0xffFFFFFF).withOpacity(0.06),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.06),
                              width: 1,
                            ),
                          ),
                          child: IconButton(
                            onPressed: () {
                              Get.back();
                            },
                            icon: Icon(
                              Icons.arrow_back_ios_new,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      Obx(() {
                        if (!controller.showCountdown.value &&
                            !controller.isLoading.value &&
                            controller.courseDetails.value != null &&
                            controller.courseDetails.value!.video.isNotEmpty) {
                          return Positioned(
                            bottom: 20,
                            right: 10,
                            child: Container(
                              height: 42,
                              width: 42,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                                color: Color(0xffFFFFFF).withOpacity(0.06),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.06),
                                  width: 1,
                                ),
                              ),
                              child: IconButton(
                                onPressed: () {
                                  _showFullscreenVideo(context);
                                },
                                icon: Icon(
                                  Icons.fullscreen,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          );
                        } else {
                          return const SizedBox.shrink();
                        }
                      }),
                    ],
                  ),
                ),
                Positioned(
                  top: MediaQuery.of(context).size.height * 0.34,
                  child: Obx(
                    () => Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.68,
                      decoration: BoxDecoration(
                        color: AppColors.appBackgroundColor,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                      ),
                      child:
                          controller.showCountdown.value
                              ? _buildCountdownUI(context)
                              : _buildCourseInfoUI(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  void _showFullscreenVideo(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    Navigator.of(context)
        .push(
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) {
              return FullscreenVideoPlayer(controller: controller);
            },
            transitionDuration: const Duration(milliseconds: 300),
            reverseTransitionDuration: const Duration(milliseconds: 300),
            transitionsBuilder: (
              context,
              animation,
              secondaryAnimation,
              child,
            ) {
              return FadeTransition(opacity: animation, child: child);
            },
          ),
        )
        .then((_) {
          SystemChrome.setPreferredOrientations([
            DeviceOrientation.portraitUp,
            DeviceOrientation.portraitDown,
          ]);
          SystemChrome.setEnabledSystemUIMode(
            SystemUiMode.manual,
            overlays: SystemUiOverlay.values,
          );
        });
  }

  Widget _buildCountdownUI(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.7,
            child: Text(
              controller.courseDetails.value?.title ?? '',
              textAlign: TextAlign.center,
              style: globalTextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 25),
          Obx(() {
            final remaining = controller.countdown.value;
            final total = controller.courseDetails.value?.courseTimer ?? 0;
            final elapsed = total - remaining;

            return Column(
              children: [
                Text(
                  controller.formatSeconds(remaining),
                  style: globalTextStyle(
                    color: AppColors.primaryColor,
                    fontSize: 50,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "min_remaining".tr,
                  style: globalTextStyle(fontSize: 16, color: Colors.white70),
                ),
                const SizedBox(height: 5),
                Text(
                  '${(elapsed / total * 100).toStringAsFixed(1)}% ${"done".tr}',
                  style: globalTextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 20),
                Obx(() {
                  final progress = controller.progress.value.clamp(0.0, 1.0);
                  return Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(30),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: progress,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppColors.primaryColor,
                                AppColors.primaryColor.withOpacity(0.7),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ],
            );
          }),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildCourseInfoUI() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: SingleChildScrollView(
        child: Column(
          children: [
            TimeContainer(
              time: controller.formatSeconds(
                controller.courseDetails.value?.courseTimer ?? 0,
              ),
              kcal: controller.courseDetails.value?.courseKcal ?? "0",
            ),
            const SizedBox(height: 20),
            DescriptionContainer(
              title: controller.courseDetails.value?.title ?? '',
              rating:
                  controller.courseDetails.value?.avgRating.toStringAsFixed(
                    1,
                  ) ??
                  '0.0',
              description: controller.courseDetails.value?.descriptions ?? '',
            ),
            const SizedBox(height: 40),
            CustomButtom(
              text: "start_training".tr,
              ontap: controller.startPreciseCountdown,
            ),
          ],
        ),
      ),
    );
  }
}

// Fullscreen Video Player
class FullscreenVideoPlayer extends StatefulWidget {
  final CategoryDetailsController controller;

  const FullscreenVideoPlayer({super.key, required this.controller});

  @override
  State<FullscreenVideoPlayer> createState() => _FullscreenVideoPlayerState();
}

class _FullscreenVideoPlayerState extends State<FullscreenVideoPlayer> {
  bool _showControls = true;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _initializeVideoListeners();
    _hideControlsAfterDelay();
  }

  void _initializeVideoListeners() {
    widget.controller.videoController.addListener(_videoListener);
    _currentPosition = widget.controller.videoController.value.position;
    _totalDuration = widget.controller.videoController.value.duration;
  }

  void _videoListener() {
    if (!_isDragging && mounted) {
      setState(() {
        _currentPosition = widget.controller.videoController.value.position;
        _totalDuration = widget.controller.videoController.value.duration;
      });
    }
  }

  @override
  void dispose() {
    widget.controller.videoController.removeListener(_videoListener);
    super.dispose();
  }

  void _hideControlsAfterDelay() {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _showControls = false;
        });
      }
    });
  }

  void _toggleControls() {
    setState(() {
      _showControls = !_showControls;
    });
    if (_showControls) {
      _hideControlsAfterDelay();
    }
  }

  void _onSliderChanged(double value) {
    setState(() {
      _currentPosition = Duration(seconds: value.toInt());
    });
  }

  void _onSliderChangeStart(double value) {
    _isDragging = true;
  }

  void _onSliderChangeEnd(double value) {
    _isDragging = false;
    final newPosition = Duration(seconds: value.toInt());
    widget.controller.videoController.seekTo(newPosition);
    _hideControlsAfterDelay();
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _toggleControls,
        child: Stack(
          children: [
            Center(
              child: AspectRatio(
                aspectRatio:
                    widget.controller.videoController.value.aspectRatio,
                child: VideoPlayer(widget.controller.videoController),
              ),
            ),
            if (_showControls)
              Container(
                color: Colors.black.withOpacity(0.3),
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 10,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: 42,
                                width: 42,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(24),
                                  color: Color(0xffFFFFFF).withOpacity(0.06),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.06),
                                    width: 1,
                                  ),
                                ),
                                child: IconButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  icon: Icon(
                                    Icons.arrow_back_ios_new,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              if (!widget.controller.showCountdown.value)
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 16,
                                    ),
                                    child: Text(
                                      widget
                                              .controller
                                              .courseDetails
                                              .value
                                              ?.title ??
                                          '',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      textAlign: TextAlign.center,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                              Container(
                                height: 42,
                                width: 42,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(24),
                                  color: Color(0xffFFFFFF).withOpacity(0.06),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.06),
                                    width: 1,
                                  ),
                                ),
                                child: IconButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  icon: Icon(
                                    Icons.fullscreen_exit,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    if (!widget.controller.showCountdown.value)
                      Center(
                        child: Obx(() {
                          return Container(
                            height: 80,
                            width: 80,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Color(0xffFFFFFF).withOpacity(0.06),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.06),
                                width: 1,
                              ),
                            ),
                            child: Center(
                              child: IconButton(
                                icon: Icon(
                                  widget.controller.isPlaying.value
                                      ? Icons.pause
                                      : Icons.play_arrow,
                                  color: Colors.white,
                                  size: 50,
                                ),
                                onPressed: () {
                                  widget.controller.toggleVideoPlayback();
                                  _hideControlsAfterDelay();
                                },
                              ),
                            ),
                          );
                        }),
                      ),
                    if (!widget.controller.showCountdown.value)
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: SafeArea(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 10,
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      _formatDuration(_currentPosition),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Expanded(
                                      child: Slider(
                                        value: _currentPosition.inSeconds
                                            .toDouble()
                                            .clamp(
                                              0.0,
                                              _totalDuration.inSeconds
                                                  .toDouble(),
                                            ),
                                        max:
                                            _totalDuration.inSeconds.toDouble(),
                                        onChanged: _onSliderChanged,
                                        onChangeStart: _onSliderChangeStart,
                                        onChangeEnd: _onSliderChangeEnd,
                                        activeColor: Colors.white,
                                        inactiveColor: Colors.white.withOpacity(
                                          0.3,
                                        ),
                                        thumbColor: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      _formatDuration(_totalDuration),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    if (widget.controller.showCountdown.value)
                      Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 20,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "training_in_progress".tr,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Obx(() {
                                final remaining =
                                    widget.controller.countdown.value;
                                return Text(
                                  widget.controller.formatSeconds(remaining),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 32,
                                    fontWeight: FontWeight.w700,
                                  ),
                                );
                              }),
                              const SizedBox(height: 5),
                              Text(
                                "min_remaining".tr,
                                style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
