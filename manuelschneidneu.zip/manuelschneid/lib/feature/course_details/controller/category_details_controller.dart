import 'dart:convert';
import 'dart:developer';
import 'dart:math' hide log;
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/course_details/model/course_details_model.dart';
import 'package:manuelschneid/feature/course_details/view/category_details_view.dart';
import 'package:manuelschneid/feature/course_details/view/widgets/show_complete_dialog.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'dart:async';

class CategoryDetailsController extends GetxController {
  late VideoPlayerController videoController;
  RxBool isPlaying = false.obs;
  RxBool isLoading = false.obs;
  RxBool showCountdown = false.obs;
  RxInt countdown = 0.obs;
  RxDouble progress = 0.0.obs;
  Rx<CourseDetailsModel?> courseDetails = Rx<CourseDetailsModel?>(null);
  RxString errorMessage = ''.obs;
  RxInt userRating = 1.obs;

  Timer? _timer;
  int _totalSeconds = 0;
  int _startTime = 0;
  bool _trainingCompleted = false;

  final RxBool showPlayButton = true.obs;

  @override
  void onInit() {
    super.onInit();
    videoController = VideoPlayerController.network('')
      ..initialize().catchError((e) {
        errorMessage.value = "failed_to_initialize_video_player".tr;
      });
  }

  void toggleVideoPlayback() {
    if (!videoController.value.isInitialized) return;

    if (videoController.value.isPlaying) {
      videoController.pause();
      isPlaying.value = false;
      showPlayButton.value = true;
    } else {
      videoController.play().catchError((e) {
        errorMessage.value = 'Failed to play video: ${e.toString()}';
      });
      isPlaying.value = true;
      showPlayButton.value = false;
    }
  }

  void toggleButtonVisibility() {
    if (isPlaying.value) {
      showPlayButton.value = !showPlayButton.value;
    }
  }

  /// Helper to format seconds into mm:ss
  String formatSeconds(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return "${minutes}m ${seconds.toString().padLeft(2, '0')}s";
  }

  /// Start countdown with seconds -> mm:ss
  void startPreciseCountdown() {
    final course = courseDetails.value;
    if (course == null || course.courseTimer <= 0) return;

    _trainingCompleted = false;
    _totalSeconds = course.courseTimer; // API gives seconds directly
    _startTime = DateTime.now().millisecondsSinceEpoch;

    countdown.value = _totalSeconds;
    progress.value = 0.0;
    showCountdown.value = true;
    isPlaying.value = true;

    videoController.play();

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      final elapsedMillis = DateTime.now().millisecondsSinceEpoch - _startTime;
      final remaining = max(0, _totalSeconds - (elapsedMillis ~/ 1000));

      progress.value = (elapsedMillis / (_totalSeconds * 1000)).clamp(0.0, 1.0);
      countdown.value = remaining;

      if (remaining <= 0 && !_trainingCompleted) {
        timer.cancel();
        _completeTraining();
        _trainingCompleted = true;
      }
    });
  }

  void _completeTraining() {
    countdown.value = 0;
    progress.value = 1.0;
    videoController.pause();
    isPlaying.value = false;

    if (!Get.isDialogOpen!) {
      showCompletionDialog(Get.context!);
    }
  }

  Future<void> initializeVideo(String url) async {
    try {
      errorMessage.value = '';
      isLoading.value = true;

      if (videoController.value.isInitialized) {
        await videoController.dispose();
      }

      videoController = VideoPlayerController.networkUrl(Uri.parse(url));
      await videoController.initialize();
      videoController.setLooping(true);
      isPlaying.value = false;
    } catch (e) {
      errorMessage.value = 'Failed to load video: ${e.toString()}';
      rethrow;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchCoursesDetails(String id) async {
    final url = "${Urls.baseUrl}/course/$id";
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');
    isLoading.value = true;
    errorMessage.value = '';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response URL: $url');
      log('Status: ${response.statusCode}');
      log('Body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);
        courseDetails.value = CourseDetailsModel.fromJson(decodedData['data']);

        if (courseDetails.value?.video.isNotEmpty ?? false) {
          await initializeVideo(courseDetails.value!.video);
        }
      } else {
        EasyLoading.showError("failed_to_get_course_details_data".tr);
      }
    } catch (e) {
      errorMessage.value = 'Error: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> getPointsApiCall(String courseId) async {
    try {
      EasyLoading.show(status: "Loading".tr);
      final url = "${Urls.baseUrl}/course/$courseId";

      SharedPreferences preferences = await SharedPreferences.getInstance();
      var token = preferences.getString('token');

      final response = await http.post(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Request URL: $url');
      log("Status: ${response.statusCode}");
      log("Body: ${response.body}");

      if (response.statusCode == 200) {
        Get.back();
        EasyLoading.showSuccess("course_points_added_successfully".tr);
      } else {
        EasyLoading.showError(
          "you_have_already_received_points_for_this_course".tr,
        );
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  Future<void> reviewsApiCall(String courseId) async {
    try {
      EasyLoading.show(status: "Loading".tr);
      final url = "${Urls.baseUrl}/review";

      SharedPreferences preferences = await SharedPreferences.getInstance();
      var token = preferences.getString('token');

      final Map<String, dynamic> inputData = {
        "courseId": courseId.trim(),
        "rating": userRating.value,
      };

      final response = await http.post(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
        body: jsonEncode(inputData),
      );

      log('Request URL: $url');
      log("Status: ${response.statusCode}");
      log("Body: ${response.body}");

      if (response.statusCode == 201) {
        EasyLoading.showSuccess("review_added_successfully".tr);
        fetchCoursesDetails(courseId);
        Get.back();
        Get.off(() => CategoryDetailsView());
      } else {
        EasyLoading.showError("you_have_already_reviewed_this_course".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  @override
  void onClose() {
    videoController.dispose();
    _timer?.cancel();
    _trainingCompleted = false;
    super.onClose();
  }
}
