class CourseDetailsModelResponse {
  final bool success;
  final String message;
  final CourseDetailsModel data;

  CourseDetailsModelResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  factory CourseDetailsModelResponse.fromJson(Map<String, dynamic> json) {
    return CourseDetailsModelResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data: CourseDetailsModel.fromJson(json['data'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {'success': success, 'message': message, 'data': data.toJson()};
  }
}

class CourseDetailsModel {
  final String id;
  final String title;
  final String category;
  final String descriptions;
  final int courseTimer;
  final String courseKcal;
  final String video;
  final String thumbnail;
  final String courseType;
  final double avgRating;
  final String createdAt;
  final String updatedAt;

  CourseDetailsModel({
    required this.id,
    required this.title,
    required this.category,
    required this.descriptions,
    required this.courseTimer,
    required this.courseKcal,
    required this.video,
    required this.thumbnail,
    required this.courseType,
    required this.avgRating,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CourseDetailsModel.fromJson(Map<String, dynamic> json) {
    return CourseDetailsModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      category: json['category'] ?? '',
      descriptions: json['descriptions'] ?? '',
      courseTimer: json['courseTimer'] ?? 0,
      courseKcal: json['courseKcal'] ?? '',
      video: json['video'] ?? '',
      thumbnail: json['thumbnail'] ?? '',
      courseType: json['courseType'] ?? '',
      avgRating:
          (json['avgRating'] != null)
              ? double.tryParse(json['avgRating'].toString()) ?? 0.0
              : 0.0,
      createdAt: json['createdAt'] ?? '',
      updatedAt: json['updatedAt'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'category': category,
      'descriptions': descriptions,
      'courseTimer': courseTimer,
      'courseKcal': courseKcal,
      'video': video,
      'thumbnail': thumbnail,
      'courseType': courseType,
      "avgRating": avgRating,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }
}
