import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_dropdown_widget.dart';
import 'package:manuelschneid/core/global_widegts/custom_multiline_textfield.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart'
    show globalTextStyle;
import 'package:manuelschneid/feature/admin/add_course_list/controller/add_course_list_controller.dart';

import 'package:manuelschneid/feature/admin/add_course_list/view/add_course_list_view.dart';

class UpdatedTraining extends StatelessWidget {
  UpdatedTraining({super.key});

  final AdminAddCourseListController controller = Get.put(
    AdminAddCourseListController(),
  );

  @override
  Widget build(BuildContext context) {
    final course = Get.arguments['courseId'];

    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchCoursesDetails(course);
    });
    if (kDebugMode) {
      print("course Id: $course");
    }

    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.to(() => AddCourseListView());
            },
            child: CircleAvatar(
              backgroundColor: Colors.white.withValues(alpha: 0.1),
              radius: 21,
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_new_sharp,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: Text(
          "Update Training",
          style: globalTextStyle(fontSize: 20, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.only(top: 15, left: 20, right: 20, bottom: 40),
        child: SingleChildScrollView(
          child: Column(
            children: [
              CustomTextField(
                verticalPadding: 16,
                controller: controller.courseTitleController,
                hintText: "Enter Course Title",
              ),
              SizedBox(height: 10),
              // Categories dropdown
              Obx(() {
                if (!controller.isDataReady.value) {
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Text(
                      "Loading categories...",
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  );
                }

                return CustomDropdown(
                  items:
                      controller.categoriesList
                          .where((category) => category.title != "All")
                          .map((category) => category.title)
                          .toList(),
                  hintText: "Enter Category",
                  controller: controller.categoryController,
                  initialValue: controller.categoryController.text,
                  waitForInitialValue: true,
                );
              }),

              SizedBox(height: 10),
              CustomMultilineTextField(
                controller: controller.curseDescriptionController,
                hintText: "Enter Course Description",
              ),
              SizedBox(height: 10),
              GestureDetector(
                onTap: () async {
                  Duration selectedDuration = Duration.zero;

                  await showModalBottomSheet(
                    context: context,
                    builder: (BuildContext context) {
                      return Container(
                        height: 250,
                        color: Colors.white,
                        child: CupertinoTimerPicker(
                          mode: CupertinoTimerPickerMode.ms,
                          initialTimerDuration: Duration.zero,
                          onTimerDurationChanged: (Duration newDuration) {
                            selectedDuration = newDuration;
                          },
                        ),
                      );
                    },
                  );

                  // Convert Duration to total seconds (integer)
                  final totalSeconds = selectedDuration.inSeconds;
                  controller.courseTimer.text = totalSeconds.toString();
                  log(
                    "Selected Course Timer (seconds): ${controller.courseTimer.text}",
                  );
                },
                child: AbsorbPointer(
                  child: CustomTextField(
                    verticalPadding: 16,
                    controller: controller.courseTimer,
                    hintText: 'enter_course_timer'.tr,
                  ),
                ),
              ),
              SizedBox(height: 10),
              CustomTextField(
                verticalPadding: 16,
                controller: controller.courseCoal,
                hintText: "Enter Course Kcal",
              ),

              SizedBox(height: 10),

              // course image
              Obx(() {
                final file = controller.courseImage.value;
                final fileName =
                    file != null
                        ? file.path.split('/').last
                        : controller.networkImage.value?.split('/').last ??
                            "Upload Course image";

                return GestureDetector(
                  onTap: controller.pickImage,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            fileName,
                            style: TextStyle(fontSize: 14, color: Colors.white),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Icon(Icons.upload_file, color: Colors.white54),
                      ],
                    ),
                  ),
                );
              }),
              SizedBox(height: 10),

              Obx(() {
                final file = controller.courseVideoController.value;
                final fileName =
                    file != null
                        ? file.path.split('/').last
                        : controller.networkVideo.value?.split('/').last ??
                            "Upload Course video";

                return GestureDetector(
                  onTap: controller.pickVideo,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            fileName,
                            style: TextStyle(fontSize: 14, color: Colors.white),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Icon(Icons.upload_file, color: Colors.white54),
                      ],
                    ),
                  ),
                );
              }),

              SizedBox(height: 10),

              Obx(() {
                // Only render dropdown when data is ready
                if (!controller.isDataReady.value) {
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 25, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Text(
                      "Loading course type...",
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  );
                }

                return CustomDropdown(
                  items: ["PAID", "UNPAID"],
                  hintText: "Enter Course Type",
                  controller: controller.courseType,
                  initialValue: controller.selectedCourseType.value,
                );
              }),

              SizedBox(height: 50),
              CustomButtom(
                contentPadding: 16,
                text: "Update Training",
                ontap: () {
                  controller.updatedCourse();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
