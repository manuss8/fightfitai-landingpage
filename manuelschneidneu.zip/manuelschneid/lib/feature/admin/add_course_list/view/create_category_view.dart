import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/admin/add_course_list/controller/add_course_list_controller.dart';
import 'package:manuelschneid/feature/admin/add_course_list/view/add_course_list_view.dart';

class CreateCategoryView extends StatelessWidget {
  CreateCategoryView({super.key});

  final AdminAddCourseListController controller = Get.put(
    AdminAddCourseListController(),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.to(() => AddCourseListView());
            },
            child: CircleAvatar(
              backgroundColor: Colors.white.withValues(alpha: 0.1),
              radius: 21,
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_new_sharp,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: Text(
          'create_category'.tr,
          style: globalTextStyle(fontSize: 20, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.only(top: 15, left: 20, right: 20, bottom: 40),
        child: Column(
          children: [
            CustomTextField(
              verticalPadding: 20,
              controller: controller.categoryName,
              hintText: 'enter_category_name'.tr,
            ),
            Spacer(),
            CustomButtom(
              contentPadding: 16,
              text: 'create_category_button'.tr,
              ontap: () {
                controller.addCategory();
              },
            ),
          ],
        ),
      ),
    );
  }
}
