import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/delete_dialog.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/admin/add_course_list/controller/add_course_list_controller.dart';
import 'package:manuelschneid/feature/admin/add_course_list/view/updated_training.dart';
import 'package:manuelschneid/feature/admin/add_course_list/widgets/show_dialog.dart';
import 'package:manuelschneid/feature/admin/admin_profile/view/admin_profile_view.dart';
import 'package:manuelschneid/feature/admin/course_details/view/admin_course_details_view.dart';
import 'package:shimmer/shimmer.dart';

class AddCourseListView extends StatelessWidget {
  AddCourseListView({super.key});

  final AdminAddCourseListController controller = Get.put(
    AdminAddCourseListController(),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              //Get.back();
              Get.to(() => AdminProfileView());
            },
            child: CircleAvatar(
              backgroundColor: Colors.white.withValues(alpha: 0.1),
              radius: 21,
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_new_sharp,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: Text(
          'course_list'.tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: GestureDetector(
              onTap: () {
                chooseAddCourseDialog();
              },
              child: CircleAvatar(
                backgroundColor: Colors.white.withValues(alpha: 0.1),
                radius: 21,
                child: Center(
                  child: Icon(Icons.add, color: Colors.white, size: 16),
                ),
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          //return controller.getCourseList();
          await controller.getCategoryList();
          await controller.getCourseList();
        },
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Obx(() {
                  if (controller.isLoader.value) {
                    // Show shimmer placeholders
                    return Row(
                      children: List.generate(5, (index) {
                        return Container(
                          width: 100,
                          height: 40,
                          margin: EdgeInsets.only(left: 20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(83),
                            color: Colors.grey.shade700,
                          ),
                          child: Shimmer.fromColors(
                            baseColor: Colors.grey.shade700,
                            highlightColor: Colors.grey.shade500,
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                vertical: 7,
                                horizontal: 20,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(83),
                              ),
                            ),
                          ),
                        );
                      }),
                    );
                  }

                  // Actual tabs
                  return Row(
                    children: List.generate(controller.categoriesList.length, (
                      index,
                    ) {
                      bool isSelected = controller.selectedIndex.value == index;
                      return GestureDetector(
                        onTap: () => controller.selectTab(index),
                        child: Stack(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: 7,
                                horizontal: 20,
                              ),
                              margin: const EdgeInsets.only(left: 20),
                              decoration: BoxDecoration(
                                color:
                                    isSelected
                                        ? AppColors.primaryColor
                                        : const Color(0xFF313131),
                                borderRadius: BorderRadius.circular(83),
                              ),
                              child: Text(
                                //controller.categoriesList[index].title,
                                controller.categoriesList[index].title == "All"
                                    ? "all".tr
                                    : controller.categoriesList[index].title,
                                style: TextStyle(
                                  color:
                                      isSelected ? Colors.black : Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),

                            // Cross Icon at top right
                            if (index != 0)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: GestureDetector(
                                  onTap: () {
                                    Get.dialog(
                                      DeleteDialog(
                                        title: "delete_category".tr,
                                        message: "delete_category_message".tr,
                                        onConfirm: () {
                                          Get.back();
                                          controller.deleteCategory(
                                            controller.categoriesList[index].id,
                                          );
                                        },
                                      ),
                                    );
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white,
                                    ),
                                    child: const Icon(
                                      Icons.close,
                                      size: 12,
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    }),
                  );
                }),
              ),
              SizedBox(height: 20),

              Expanded(
                child: Obx(() {
                  if (controller.isLoading.value) {
                    // Show shimmer loading
                    return ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: 4,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(
                            left: 10,
                            right: 15,
                            bottom: 20,
                          ),
                          child: Shimmer.fromColors(
                            baseColor: Colors.grey.shade700,
                            highlightColor: Colors.grey.shade600,
                            child: Container(
                              width: double.infinity,
                              height: 204,
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(22),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  }

                  if (controller.filteredCourseList.isEmpty) {
                    return Center(
                      child: Text(
                        'no_courses_available'.tr,
                        style: const TextStyle(color: Colors.grey),
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: controller.filteredCourseList.length,
                    itemBuilder: (BuildContext context, int index) {
                      final course = controller.filteredCourseList[index];
                      return Padding(
                        padding: const EdgeInsets.only(
                          left: 10,
                          right: 15.0,
                          bottom: 20,
                        ),
                        child: GestureDetector(
                          onTap: () {
                            Get.to(
                              () => AdminCourseDetailsView(),
                              arguments: {'courseId': course.id},
                            );
                          },
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(22),
                            child: Stack(
                              children: [
                                CachedNetworkImage(
                                  imageUrl: course.thumbnail,
                                  width: double.infinity,
                                  height: 204,
                                  fit: BoxFit.cover,
                                  placeholder:
                                      (context, url) => Shimmer.fromColors(
                                        baseColor: Colors.grey.shade700,
                                        highlightColor: Colors.grey.shade500,
                                        child: Container(color: Colors.grey),
                                      ),
                                  errorWidget:
                                      (context, url, error) => Container(
                                        color: Colors.grey.shade800,
                                        child: Icon(
                                          Icons.broken_image,
                                          color: Colors.red,
                                        ),
                                      ),
                                ),
                                Positioned.fill(
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            /// More button (Edit/Delete)
                                            PopupMenuButton<String>(
                                              onSelected: (value) {
                                                if (value == 'Edit') {
                                                  Get.to(
                                                    () => UpdatedTraining(),
                                                    arguments: {
                                                      'courseId': course.id,
                                                    },
                                                  );
                                                } else if (value == 'Delete') {
                                                  Get.dialog(
                                                    DeleteDialog(
                                                      title: "delete_course".tr,
                                                      message:
                                                          "delete_confirmation"
                                                              .tr,
                                                      onConfirm: () {
                                                        Get.back();
                                                        controller.deleteCourse(
                                                          course.id,
                                                        );
                                                      },
                                                    ),
                                                  );
                                                }
                                              },
                                              icon: Icon(
                                                Icons.more_vert,
                                                color: Colors.white,
                                              ),
                                              itemBuilder:
                                                  (
                                                    BuildContext context,
                                                  ) => <PopupMenuEntry<String>>[
                                                    PopupMenuItem<String>(
                                                      value: 'Edit',
                                                      child: Row(
                                                        children: [
                                                          Icon(
                                                            Icons.edit,
                                                            color:
                                                                AppColors
                                                                    .primaryColor,
                                                          ),
                                                          SizedBox(width: 8),
                                                          Text(
                                                            'edit'.tr,
                                                            style:
                                                                globalTextStyle(
                                                                  color:
                                                                      Colors
                                                                          .black,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    PopupMenuItem<String>(
                                                      value: 'Delete',
                                                      child: Row(
                                                        children: [
                                                          Icon(
                                                            Icons.delete,
                                                            color: Colors.red,
                                                          ),
                                                          SizedBox(width: 8),
                                                          Text(
                                                            'delete'.tr,
                                                            style:
                                                                globalTextStyle(
                                                                  color:
                                                                      Colors
                                                                          .black,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                            ),

                                            /// Rating Box
                                            Container(
                                              width: 80,
                                              decoration: BoxDecoration(
                                                color: Colors.white.withOpacity(
                                                  0.06,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(52),
                                                border: Border.all(
                                                  color: Colors.white
                                                      .withOpacity(0.05),
                                                ),
                                              ),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 8,
                                                      vertical: 4,
                                                    ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      Icons.star,
                                                      color:
                                                          AppColors
                                                              .primaryColor,
                                                      size: 18,
                                                    ),
                                                    const SizedBox(width: 5),
                                                    Text(
                                                      course.avgRating
                                                          .toString(),
                                                      style: globalTextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const Spacer(),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                course.title,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: globalTextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            ),

                                            SizedBox(width: 10),
                                            Container(
                                              width: 82,
                                              decoration: BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              child: Center(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(
                                                    8.0,
                                                  ),
                                                  child: Text(
                                                    course.category,
                                                    maxLines: 2,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: globalTextStyle(
                                                      color: Colors.black,
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
