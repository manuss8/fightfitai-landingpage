import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/admin/add_course_list/model/categories_model.dart';
import 'package:manuelschneid/feature/admin/add_course_list/model/course_model.dart';
import 'package:manuelschneid/feature/admin/add_course_list/view/add_course_list_view.dart';
import 'package:manuelschneid/feature/admin/course_details/model/course_details_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdminAddCourseListController extends GetxController {
  final TextEditingController categoryName = TextEditingController();
  final TextEditingController courseTitleController = TextEditingController();
  final TextEditingController categoryController = TextEditingController();
  final TextEditingController curseDescriptionController =
      TextEditingController();
  final TextEditingController courseTimer = TextEditingController();
  final TextEditingController courseCoal = TextEditingController();
  final TextEditingController courseType = TextEditingController();

  Rx<CourseDetailsModel?> courseDetails = Rx<CourseDetailsModel?>(null);
  RxBool isDataReady = false.obs;
  RxString selectedCourseType = RxString('');

  var courseImage = Rx<File?>(null);
  var networkImage = Rx<String?>('');

  var courseVideoController = Rx<File?>(null);
  var networkVideo = Rx<String?>('');

  RxList<CategoryData> categoriesList = <CategoryData>[].obs;
  RxList<CourseData> courseList = <CourseData>[].obs;
  RxList<CourseData> filteredCourseList = <CourseData>[].obs;

  RxBool isLoading = false.obs;
  RxBool isLoader = false.obs;

  // Add video loading state
  RxBool isVideoLoading = false.obs;

  var selectedIndex = 0.obs;

  @override
  void onInit() async {
    super.onInit();
    getCategoryList();
    getCourseList();
  }

  void selectTab(int index) {
    selectedIndex.value = index;
    final selectedCategory = categoriesList[index].title;
    filterCourseByCategory(selectedCategory);
  }

  // pick image method
  Future<void> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile != null) {
      courseImage.value = File(pickedFile.path);
      networkImage.value = null;
    }
  }

  // Updated pick video method with loading state
  Future<void> pickVideo() async {
    try {
      // Start loading
      isVideoLoading.value = true;
      EasyLoading.show(status: 'selecting_video'.tr);

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.video,
      );

      if (result != null && result.files.single.path != null) {
        // Set the selected video file
        courseVideoController.value = File(result.files.single.path!);
        networkVideo.value =
            null; // Clear network video if local video is selected

        EasyLoading.showSuccess('video_selected_successfully'.tr);
      } else {
        // User cancelled the selection
        courseVideoController.value = null;
        EasyLoading.showInfo('video_selection_cancelled'.tr);
      }
    } catch (e) {
      // Handle any errors during video selection
      if (kDebugMode) {
        print("Error picking video: $e");
      }
      EasyLoading.showError('failed_to_select_video'.tr);
      courseVideoController.value = null;
    } finally {
      // Stop loading regardless of success or failure
      isVideoLoading.value = false;
      EasyLoading.dismiss();
    }
  }

  // add category method........
  Future<void> addCategory() async {
    final url = Urls.addcategory;

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');
    String category = categoryName.text.trim();

    if (category.isEmpty) {
      EasyLoading.showToast('please_enter_category_name'.tr);
      return;
    }

    try {
      EasyLoading.show(status: 'loading'.tr);
      var response = await http.post(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
        body: jsonEncode({"title": category}),
      );

      log("Response Urls: $url");
      log("Response status code: ${response.statusCode}");
      log("Response body: ${response.body}");

      if (response.statusCode == 201) {
        EasyLoading.showSuccess('category_added_successfully'.tr);
        Get.offAll(() => AddCourseListView());
      } else {
        EasyLoading.showError('failed_to_add_category'.tr);
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // get category list method........
  Future<void> getCategoryList() async {
    final url = Urls.getcategory;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      isLoader.value = true;
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response Category URL: $url');
      log('Response CategoryStatus code: ${response.statusCode}');
      log('Response Category body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);

        if (decodedData['data'] != null) {
          AdminCategoriesModel categoriesModel = AdminCategoriesModel.fromJson(
            decodedData,
          );
          categoriesList.value = categoriesModel.data;
          // Add "All" category at the beginning
          categoriesList.value = [
            CategoryData(title: "All", id: "all", createdAt: "", updatedAt: ""),
            ...categoriesModel.data,
          ];
        } else {
          EasyLoading.showError('no_category_data_found'.tr);
        }
      } else {
        EasyLoading.showError('failed_to_get_category_data'.tr);
        if (kDebugMode) {
          print('Failed to get category data!');
        }
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      isLoader.value = false;
      EasyLoading.dismiss();
    }
  }

  // add course method........
  Future<bool> addCourse() async {
    EasyLoading.show(status: "loading".tr);
    final url = Urls.addcourse;

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      final request = http.MultipartRequest('POST', Uri.parse(url));

      request.headers['Authorization'] = "$token";

      // Parse course timer as integer seconds
      int finalTimerValue = int.tryParse(courseTimer.text.trim()) ?? 0;

      // data part
      Map<String, dynamic> courseData = {
        "title": courseTitleController.text.trim(),
        "category": categoryController.text.trim(),
        "descriptions": curseDescriptionController.text.trim(),
        "courseTimer": finalTimerValue, // send as integer seconds
        "courseKcal": courseCoal.text.trim(),
        "courseType": courseType.text.trim(),
      };

      // Print the data being sent
      log("=== ADD COURSE REQUEST DATA ===");
      log("Course Data Map: $courseData");
      String jsonData = jsonEncode(courseData);
      log("Course Data JSON: $jsonData");
      log("===============================");

      // data part
      request.fields.addAll({"data": jsonData});

      // Rest of your code remains the same...
      // image part
      if (courseImage.value != null) {
        var imageBytes = await courseImage.value!.readAsBytes();
        var imageFile = http.MultipartFile.fromBytes(
          'thumbnail',
          imageBytes,
          filename: courseImage.value!.path.split('/').last,
        );
        request.files.add(imageFile);
      }

      // video part
      if (courseVideoController.value != null &&
          courseVideoController.value!.path.isNotEmpty) {
        var videoBytes = await courseVideoController.value!.readAsBytes();
        var videoFile = http.MultipartFile.fromBytes(
          'file',
          videoBytes,
          filename: courseVideoController.value!.path.split('/').last,
        );
        request.files.add(videoFile);
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      log("Response URL: $url");
      log('Response Status code: ${response.statusCode}');
      log('Response Body========>>>: $responseBody');

      if (response.statusCode == 201) {
        EasyLoading.showSuccess('add_course_successfully'.tr);
        Get.to(() => AddCourseListView());
        resetForm();
        getCourseList();
        return true;
      } else {
        EasyLoading.showError('failed_to_add_course'.tr);
        return false;
      }
    } catch (e) {
      // Your existing error handling...
      if (kDebugMode) {
        print("Error: $e");
      }
      return false;
    } finally {
      EasyLoading.dismiss();
    }
  }

  // update course method........
  Future<void> updatedCourse() async {
    EasyLoading.show(status: "loading".tr);
    final url = "${Urls.baseUrl}/course/${courseDetails.value?.id}";

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      final request = http.MultipartRequest('PUT', Uri.parse(url));
      request.headers['Authorization'] = "$token";

      // Parse course timer as integer seconds
      int finalTimerValue = int.tryParse(courseTimer.text.trim()) ?? 0;

      // data part
      Map<String, dynamic> courseData = {
        "title": courseTitleController.text.trim(),
        "category": categoryController.text.trim(),
        "descriptions": curseDescriptionController.text.trim(),
        "courseTimer": finalTimerValue, // send as integer seconds
        "courseKcal": courseCoal.text.trim(),
        "courseType": courseType.text.trim(),
      };

      // Print the data being sent
      log("=== ADD COURSE REQUEST DATA ===");
      log("Course Data Map: $courseData");
      String jsonData = jsonEncode(courseData);
      log("Course Data JSON: $jsonData");
      log("===============================");

      // data part
      request.fields.addAll({"data": jsonData});

      // Rest of your existing updatedCourse method code...
      // image
      if (courseImage.value != null) {
        var imageBytes = await courseImage.value!.readAsBytes();
        var imageFile = http.MultipartFile.fromBytes(
          'thumbnail',
          imageBytes,
          filename: courseImage.value!.path.split('/').last,
        );
        request.files.add(imageFile);
      } else if (networkImage.value != null) {
        request.fields['thumbnailUrl'] = networkImage.value!;
      }

      // video
      if (courseVideoController.value != null) {
        var videoBytes = await courseVideoController.value!.readAsBytes();
        var videoFile = http.MultipartFile.fromBytes(
          'file',
          videoBytes,
          filename: courseVideoController.value!.path.split('/').last,
        );
        request.files.add(videoFile);
      } else if (networkVideo.value != null) {
        request.fields['videoUrl'] = networkVideo.value!;
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      log('Response URL: $url');
      log('Response Status code: ${response.statusCode}');
      log('Response Body: $responseBody');

      if (response.statusCode == 200) {
        EasyLoading.showSuccess('course_updated_successfully'.tr);
        resetForm();
        Get.to(() => AddCourseListView());
      } else {
        EasyLoading.showError('update_failed'.tr);
      }
    } catch (e) {
      print("Update error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  // get course list method........
  Future<void> getCourseList() async {
    //final url = Urls.getcourse;
    final url = "${Urls.baseUrl}/course/for-admin";
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      isLoading.value = true;
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response Category URL: $url');
      log('Response CategoryStatus code: ${response.statusCode}');
      log('Response Category body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);

        if (decodedData['data'] != null) {
          List<CourseData> courses =
              (decodedData['data'] as List)
                  .map((item) => CourseData.fromJson(item))
                  .toList();
          courseList.value = courses;
          // Show all initially
          filterCourseByCategory("All");
        } else {
          EasyLoading.showError('no_course_data_found'.tr);
        }
      } else {
        EasyLoading.showError('failed_to_get_course_data'.tr);
        if (kDebugMode) {
          print('Failed to get category data!');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      isLoading.value = false;
      EasyLoading.dismiss();
    }
  }

  // Fetch course details.....
  Future<void> fetchCoursesDetails(String id) async {
    isDataReady.value = false;
    isLoading.value = true;

    try {
      // Load categories if not already loaded
      if (categoriesList.isEmpty) {
        await getCategoryList();
      }

      // Load course details
      final url = "${Urls.baseUrl}/course/$id";
      final preferences = await SharedPreferences.getInstance();
      final token = preferences.getString('token');

      final response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);
        courseDetails.value = CourseDetailsModel.fromJson(decodedData['data']);

        // Update controllers
        courseTitleController.text = courseDetails.value?.title ?? '';
        categoryController.text = courseDetails.value?.category.trim() ?? '';
        curseDescriptionController.text =
            courseDetails.value?.descriptions ?? '';
        courseTimer.text = courseDetails.value?.courseTimer.toString() ?? '';
        courseCoal.text = courseDetails.value?.courseKcal.toString() ?? '';

        // Explicitly handle course type
        final courseTypeValue = courseDetails.value?.courseType ?? '';
        courseType.text = courseTypeValue;
        selectedCourseType.value = courseTypeValue;

        // Set network URLs
        networkImage.value = courseDetails.value?.thumbnail ?? '';
        networkVideo.value = courseDetails.value?.video ?? '';

        isDataReady.value = true;
      }
    } finally {
      isLoading.value = false;
    }
  }

  // Post notification method..when add new course
  Future<void> createNotification() async {
    final url = Urls.postNotificationss;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      var response = await http.post(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },

        body: jsonEncode({
          "title": 'new_course_available'.tr,
          "body": 'new_course_added_notification'.tr,
        }),
      );

      log("Response Urls: $url");
      log("Response status code: ${response.statusCode}");
      log("Response body: ${response.body}");

      if (response.statusCode == 200) {
        log("Notification sending successfully.");
      } else {
        //EasyLoading.showError("Failed to add category.");
        log("Notification sending failed.");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // Delete course method...............
  Future<void> deleteCourse(String courseId) async {
    final url = "${Urls.baseUrl}/course/$courseId";
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      EasyLoading.show(status: 'deleting'.tr);
      var response = await http.delete(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Delete Course URL: $url');
      log('Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200 || response.statusCode == 204) {
        // Optionally parse response if needed
        EasyLoading.showSuccess('course_deleted_successfully'.tr);
        getCourseList();
      } else {
        EasyLoading.showError('failed_to_delete_course'.tr);
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error deleting course: $e");
      }
      EasyLoading.showError('something_went_wrong'.tr);
    } finally {
      EasyLoading.dismiss();
    }
  }

  // Delete category method...............
  Future<void> deleteCategory(String categoryId) async {
    final url = "${Urls.baseUrl}/category/$categoryId";
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      EasyLoading.show(status: 'deleting'.tr);
      var response = await http.delete(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Delete Course URL: $url');
      log('Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        // Optionally parse response if needed
        EasyLoading.showSuccess('category_deleted_successfully'.tr);
        getCategoryList();
      } else {
        EasyLoading.showError('failed_to_delete_category'.tr);
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error deleting course: $e");
      }
      EasyLoading.showError('something_went_wrong'.tr);
    } finally {
      EasyLoading.dismiss();
    }
  }

  // Filter course by category
  void filterCourseByCategory(String category) {
    if (category == "All") {
      filteredCourseList.value = courseList;
    } else {
      filteredCourseList.value =
          courseList.where((course) => course.category == category).toList();
    }
  }

  // clear form...
  void resetForm() {
    courseTitleController.clear();
    categoryController.clear();
    curseDescriptionController.clear();
    courseTimer.clear();
    courseCoal.clear();
    courseType.clear();

    courseImage.value = null;
    courseVideoController.value = null;

    networkImage.value = null;
    networkVideo.value = null;

    courseDetails.value = null;

    // Reset video loading state
    isVideoLoading.value = false;
  }
}
