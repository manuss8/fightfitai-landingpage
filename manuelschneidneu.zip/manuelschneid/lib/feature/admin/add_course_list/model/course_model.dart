class AdminCourseModel {
  final bool success;
  final String message;
  final List<CourseData> data;

  AdminCourseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  factory AdminCourseModel.fromJson(Map<String, dynamic> json) {
    return AdminCourseModel(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data:
          (json['data'] as List<dynamic>?)
              ?.map((e) => CourseData.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class CourseData {
  final String id;
  final String title;
  final String category;
  final String descriptions;
  final int courseTimer;
  final String courseKcal;
  final String video;
  final String thumbnail;
  final String courseType;
  final double avgRating;
  final DateTime createdAt;
  final DateTime updatedAt;

  CourseData({
    required this.id,
    required this.title,
    required this.category,
    required this.descriptions,
    required this.courseTimer,
    required this.courseKcal,
    required this.video,
    required this.thumbnail,
    required this.courseType,
    required this.avgRating,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CourseData.fromJson(Map<String, dynamic> json) {
    return CourseData(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      category: json['category'] ?? '',
      descriptions: json['descriptions'] ?? '',
      courseTimer: json['courseTimer'] ?? 0,
      courseKcal: json['courseKcal'] ?? '',
      video: json['video'] ?? '',
      thumbnail: json['thumbnail'] ?? '',
      courseType: json['courseType'] ?? '',
      avgRating:
          (json['avgRating'] != null)
              ? double.tryParse(json['avgRating'].toString()) ?? 0.0
              : 0.0,
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
      "category": category,
      "descriptions": descriptions,
      "courseTimer": courseTimer,
      "courseKcal": courseKcal,
      "video": video,
      "thumbnail": thumbnail,
      "courseType": courseType,
      "avgRating": avgRating,
      "createdAt": createdAt.toIso8601String(),
      "updatedAt": updatedAt.toIso8601String(),
    };
  }
}
