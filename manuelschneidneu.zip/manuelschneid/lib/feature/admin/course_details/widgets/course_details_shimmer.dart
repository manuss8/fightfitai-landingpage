import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class AdminCourseDetailsShimmer extends StatelessWidget {
  const AdminCourseDetailsShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: double.infinity,
      width: double.infinity,
      child: Column(
        children: [
          Shimmer.fromColors(
            baseColor: Colors.grey[800]!,
            highlightColor: Colors.grey[700]!,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.35,
              width: double.infinity,
              color: Colors.grey,
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Shimmer.fromColors(
                baseColor: Colors.grey[600]!,
                highlightColor: Colors.grey[500]!,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 20, width: 200, color: Colors.grey),
                    SizedBox(height: 16),
                    Container(
                      height: 16,
                      width: double.infinity,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 8),
                    Container(
                      height: 16,
                      width: double.infinity,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 8),
                    Container(
                      height: 16,
                      width: double.infinity,
                      color: Colors.grey,
                    ),
                   
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
