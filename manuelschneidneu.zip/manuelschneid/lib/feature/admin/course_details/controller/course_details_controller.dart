import 'dart:convert';
import 'dart:developer';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/admin/course_details/model/course_details_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'dart:async';

class AdminCourseDetailsController extends GetxController {
  late VideoPlayerController videoController;
  RxBool isPlaying = false.obs;
  RxBool isLoading = false.obs;
  RxBool showCountdown = false.obs;
  RxInt countdown = 10.obs;
  RxDouble progress = 0.0.obs;
  Timer? _timer;
  Rx<CourseDetailsModel?> courseDetails = Rx<CourseDetailsModel?>(null);
  RxString errorMessage = ''.obs;
  final RxBool showPlayButton = true.obs;

  @override
  void onInit() {
    super.onInit();
    // Initialize with empty controller
    videoController = VideoPlayerController.network('')
      ..initialize().catchError((e) {
        errorMessage.value = 'Failed to initialize video player';
      });
  }

  // Initialize the video player
  Future<void> initializeVideo(String url) async {
    try {
      errorMessage.value = '';
      isLoading.value = true;

      // Dispose previous controller if exists
      if (videoController.value.isInitialized) {
        await videoController.dispose();
      }

      videoController = VideoPlayerController.networkUrl(Uri.parse(url))
        ..addListener(() {
          if (videoController.value.isInitialized) {
            progress.value =
                videoController.value.position.inMilliseconds /
                videoController.value.duration.inMilliseconds;
          }
        });

      await videoController.initialize();
      videoController.setLooping(true);
      isPlaying.value = false;
    } catch (e) {
      errorMessage.value = 'Failed to load video: ${e.toString()}';
      rethrow;
    } finally {
      isLoading.value = false;
    }
  }

  // // Toggle video play/pause
  // void toggleVideoPlayback() {
  //   if (!videoController.value.isInitialized) return;

  //   if (videoController.value.isPlaying) {
  //     videoController.pause();
  //     isPlaying.value = false;
  //   } else {
  //     videoController.play().catchError((e) {
  //       errorMessage.value = 'Failed to play video: ${e.toString()}';
  //     });
  //     isPlaying.value = true;
  //   }
  // }

  void toggleVideoPlayback() {
    if (!videoController.value.isInitialized) return;

    if (videoController.value.isPlaying) {
      videoController.pause();
      isPlaying.value = false;
      showPlayButton.value = true; // ✅ Show play button when paused
    } else {
      videoController.play().catchError((e) {
        errorMessage.value = 'Failed to play video: ${e.toString()}';
      });
      isPlaying.value = true;
      showPlayButton.value = false; // ✅ Hide play button when playing
    }
  }

  void toggleButtonVisibility() {
    if (isPlaying.value) {
      showPlayButton.value = !showPlayButton.value;
    }
  }

  // Fetch course details
  Future<void> fetchCoursesDetails(String id) async {
    final url = "${Urls.baseUrl}/course/$id";
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');
    isLoading.value = true;
    errorMessage.value = '';

    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response URL: $url');
      log('Response Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);
        courseDetails.value = CourseDetailsModel.fromJson(decodedData['data']);

        if (courseDetails.value?.video.isNotEmpty ?? false) {
          await initializeVideo(courseDetails.value!.video);
        }
      } else {
        EasyLoading.showError("Failed to get course details data.");
      }
    } catch (e) {
      errorMessage.value = 'Error: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    videoController.dispose();
    _timer?.cancel();
    super.onClose();
  }
}
