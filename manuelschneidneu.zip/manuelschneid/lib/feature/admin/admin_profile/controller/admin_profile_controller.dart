import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/feature/admin/admin_profile/model/admin_profile_model.dart';
import 'package:manuelschneid/route/app_route.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdminProfileController extends GetxController {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController oldPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  Rx<AdminProfileModel?> userProfile = Rx<AdminProfileModel?>(null);

  var profileImage = Rx<File?>(null);
  var networkImage = Rx<String?>(null);

  var isOldPasswordVisible = true.obs;
  var isNewPasswordVisible = true.obs;
  var isConfirmPasswordVisible = true.obs;

  RxBool islanguageSwitch = false.obs;
  final box = GetStorage();

  void toggleLanguageSwitch(bool value) {
    islanguageSwitch.value = value;
    if (value) {
      // Switch ON = English
      // Get.updateLocale(const Locale('en', 'US'));
      // box.write('language', 'en');
      Get.updateLocale(const Locale('de', 'DE'));
      box.write('language', 'de');
    } else {
      // Switch OFF = German
      // Get.updateLocale(const Locale('de', 'DE'));
      // box.write('language', 'de');

      Get.updateLocale(const Locale('en', 'US'));
      box.write('language', 'en');
    }
  }

  @override
  void onInit() async {
    super.onInit();
    await getUserProfile();
    nameController.text = userProfile.value?.data.userName ?? 'no_user_name'.tr;
    emailController.text = userProfile.value?.data.email ?? 'no_email'.tr;
    networkImage.value = userProfile.value?.data.profileImage;
  }

  void toggleOldPasswordVisibility() {
    isOldPasswordVisible.value = !isOldPasswordVisible.value;
  }

  void toggleNewPasswordVisibility() {
    isNewPasswordVisible.value = !isNewPasswordVisible.value;
  }

  void toggleConfirmPasswordVisibility() {
    isConfirmPasswordVisible.value = !isConfirmPasswordVisible.value;
  }

  // pick image method
  Future<void> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile != null) {
      profileImage.value = File(pickedFile.path);
      networkImage.value = null;
    }
  }

  // get profile method......
  Future<void> getUserProfile() async {
    final url = Urls.getUser;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Response URL: $url');
      log('Response Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);

        if (decodedData['data'] != null) {
          AdminProfileModel profileModel = AdminProfileModel.fromJson(
            decodedData,
          );
          userProfile.value = profileModel;
        } else {
          EasyLoading.showError('no_user_data_found'.tr);
        }
      } else {
        EasyLoading.showError('failed_to_get_user_data'.tr);
        if (kDebugMode) {
          print('Failed to get user data!');
        }
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // updated profile method........
  Future<void> updateProfile() async {
    EasyLoading.show(status: 'loading'.tr);
    final url = Urls.updateProfile;

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    var dataFields = {
      "profileData": jsonEncode({"userName": nameController.text.trim()}),
    };

    try {
      final request = http.MultipartRequest('PUT', Uri.parse(url));

      request.headers.addAll({
        'Content-Type': 'multipart/form-data',
        'Authorization': "$token",
      });

      request.fields.addAll(dataFields);

      if (profileImage.value != null) {
        var imageBytes = await profileImage.value!.readAsBytes();
        var imageFile = http.MultipartFile.fromBytes(
          'image',
          imageBytes,
          filename: profileImage.value!.path.split('/').last,
        );
        request.files.add(imageFile);
      }

      final response = await request.send();

      log("Response URL: $url");
      log('Response Status code: ${response.statusCode}');

      if (response.statusCode == 200) {
        EasyLoading.showSuccess('profile_updated_successfully'.tr);
        Get.back();
        getUserProfile();
      } else {
        EasyLoading.showError('failed_to_update_profile'.tr);
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // set changePassword method........
  Future<void> changePassword() async {
    EasyLoading.show(status: 'loading'.tr);
    final url = Urls.changePassword;

    String currentPassword = oldPasswordController.text.trim();
    String newPassword = newPasswordController.text.trim();
    String confirmPassword = confirmPasswordController.text.trim();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    if (currentPassword.isEmpty) {
      EasyLoading.showToast('please_enter_current_password'.tr);
      return;
    }

    if (newPassword.isEmpty) {
      EasyLoading.showToast('please_enter_new_password'.tr);
      return;
    } else if (newPassword.length < 8) {
      EasyLoading.showToast('password_length_error'.tr);
      return;
    }

    if (confirmPassword.isEmpty) {
      EasyLoading.showToast('please_confirm_password'.tr);
      return;
    } else if (newPassword != confirmPassword) {
      EasyLoading.showToast('passwords_do_not_match'.tr);
      return;
    } else if (currentPassword == newPassword) {
      EasyLoading.showToast('new_password_same_as_old'.tr);
      return;
    }

    try {
      final body = json.encode({
        "oldPassword": currentPassword,
        "newPassword": newPassword,
      });

      final response = await http.put(
        Uri.parse(url),
        body: body,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "$token",
        },
      );

      log('Response URL: $url');
      log('Response Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        EasyLoading.showSuccess('password_changed_successfully'.tr);
        Get.back();
        oldPasswordController.clear();
        newPasswordController.clear();
        confirmPasswordController.clear();
      } else {
        EasyLoading.showError('failed_to_change_password'.tr);
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // log out method.............
  Future<void> logout() async {
    try {
      EasyLoading.show(status: 'logging_out'.tr);
      await SharePref.clearAll();

      Get.offAllNamed(AppRoute.signinScreen);

      EasyLoading.showSuccess('logout_successful'.tr);

      EasyLoading.dismiss();
    } catch (e) {
      EasyLoading.showError('failed_to_logout'.tr);
    }
  }
}
