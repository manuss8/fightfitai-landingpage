import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart' show AppColors;
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/admin/add_course_list/view/add_course_list_view.dart';
import 'package:manuelschneid/feature/admin/admin_profile/view/change_password_view.dart';
import 'package:manuelschneid/feature/admin/admin_profile/view/edit_profile_view.dart';
import 'package:manuelschneid/feature/admin/admin_profile/controller/admin_profile_controller.dart';
import 'package:manuelschneid/feature/admin/admin_profile/view/widgets/login_type.dart';

class AdminProfileView extends StatelessWidget {
  AdminProfileView({super.key});

  final AdminProfileController controller = Get.put(AdminProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 65, left: 14, right: 14, bottom: 10),
          child: Column(
            children: [
              Center(
                child: Text(
                  'profile'.tr,
                  style: globalTextStyle(
                    color: Color(0xFFF1F2F6),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 30),
              Obx(
                () => CircleAvatar(
                  radius: 50,
                  backgroundColor: AppColors.primaryColor,
                  child: CircleAvatar(
                    radius: 48,
                    backgroundImage:
                        (controller.userProfile.value?.data.profileImage !=
                                    null &&
                                controller
                                    .userProfile
                                    .value!
                                    .data
                                    .profileImage
                                    .isNotEmpty)
                            ? NetworkImage(
                              controller.userProfile.value!.data.profileImage,
                            )
                            : const AssetImage(IconsPath.profileAvater)
                                as ImageProvider,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Obx(
                () => Text(
                  controller.userProfile.value?.data.userName ??
                      'no_user_name'.tr,
                  style: globalTextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 5),
              Obx(
                () => Text(
                  controller.userProfile.value?.data.email ?? 'no_email'.tr,
                  style: globalTextStyle(
                    color: Color(0xFFF1F2F6).withValues(alpha: 0.64),
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(height: 30),
              LoginProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.editProfile,
                avaterColor: AppColors.primaryColor,
                text: 'edit_profile'.tr,
                onTap: () {
                  Get.to(() => AdminEditProfileView());
                },
              ),
              SizedBox(height: 18),
              LoginProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.lockIcon,
                avaterColor: AppColors.primaryColor,
                text: 'change_password'.tr,
                onTap: () {
                  Get.to(() => AdminChangePasswordView());
                },
              ),
              SizedBox(height: 18),
              LoginProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.courseList,
                avaterColor: AppColors.primaryColor,
                text: 'course_list'.tr,
                onTap: () {
                  Get.to(() => AddCourseListView());
                },
              ),
              SizedBox(height: 18),

              // Language selection section
              Container(
                padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: Colors.white.withValues(alpha: 0.06),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Icon(
                            Icons.language,
                            color: Colors.white.withValues(alpha: 0.6),
                            size: 18,
                          ),
                        ),
                        SizedBox(width: 20),
                        Text(
                          "language".tr,
                          style: globalTextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    FlutterSwitch(
                      width: 70.0,
                      height: 35.0,
                      toggleSize: 30.0,
                      value: controller.islanguageSwitch.value,
                      borderRadius: 30.0,
                      padding: 4.0,
                      activeColor: Colors.white.withValues(alpha: 0.18),
                      inactiveColor: Colors.white.withValues(alpha: 0.18),
                      showOnOff: true,
                      toggleColor: AppColors.primaryColor,
                      activeText: "GE",
                      inactiveText: "EN",
                      activeTextFontWeight: FontWeight.w600,
                      inactiveTextFontWeight: FontWeight.w600,
                      activeTextColor: Colors.white,
                      inactiveTextColor: Colors.white,
                      onToggle: controller.toggleLanguageSwitch,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 18),
              SizedBox(height: 18),
              LoginProfileContentContainer(
                containerColor: Color(0xFFFF4B4B),
                textColor: Colors.white,
                image: IconsPath.logout,
                text: 'logout'.tr,
                onTap: () {
                  controller.logout();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
