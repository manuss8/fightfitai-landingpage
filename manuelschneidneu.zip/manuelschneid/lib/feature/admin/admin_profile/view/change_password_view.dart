import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/admin/admin_profile/controller/admin_profile_controller.dart';

class AdminChangePasswordView extends StatelessWidget {
  AdminChangePasswordView({super.key});

  final AdminProfileController controller = Get.put(AdminProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              backgroundColor: Colors.white.withValues(alpha: 0.1),
              radius: 21,
              child: Center(
                child: Icon(
                  Icons.arrow_back_ios_new_sharp,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ),
        ),
        title: Text(
          'change_password_title'.tr,
          style: globalTextStyle(fontSize: 20, fontWeight: FontWeight.w600),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 15, bottom: 35),
        child: Column(
          children: [
            Obx(
              () => CustomTextField(
                isObscure: controller.isOldPasswordVisible.value,
                controller: controller.oldPasswordController,
                hintText: 'old_password'.tr,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.isOldPasswordVisible.value
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Color(0xFF7E7D7C),
                  ),
                  onPressed: () {
                    controller.toggleOldPasswordVisibility();
                  },
                ),
              ),
            ),
            SizedBox(height: 15),
            Obx(
              () => CustomTextField(
                isObscure: controller.isNewPasswordVisible.value,
                controller: controller.newPasswordController,
                hintText: 'new_password'.tr,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.isNewPasswordVisible.value
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Color(0xFF7E7D7C),
                  ),
                  onPressed: () {
                    controller.toggleNewPasswordVisibility();
                  },
                ),
              ),
            ),
            SizedBox(height: 15),
            Obx(
              () => CustomTextField(
                isObscure: controller.isConfirmPasswordVisible.value,
                controller: controller.confirmPasswordController,
                hintText: 'confirm_password'.tr,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.isConfirmPasswordVisible.value
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Color(0xFF7E7D7C),
                  ),
                  onPressed: () {
                    controller.toggleConfirmPasswordVisibility();
                  },
                ),
              ),
            ),
            Spacer(),
            CustomButtom(
              contentPadding: 20,
              text: 'save'.tr,
              ontap: () {
                controller.changePassword();
              },
            ),
            SizedBox(height: 15),
            CustomButtom(
              buttonColor: Colors.white.withValues(alpha: 0.06),
              textColor: Colors.white,
              contentPadding: 20,
              text: 'cancel'.tr,
              ontap: () {
                Get.back();
              },
            ),
          ],
        ),
      ),
    );
  }
}
