import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart'
    show globalTextStyle;
import 'package:manuelschneid/feature/admin/admin_profile/controller/admin_profile_controller.dart';

class AdminEditProfileView extends StatelessWidget {
  AdminEditProfileView({super.key});

  final AdminProfileController controller = Get.put(AdminProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
              child: Center(
                child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
              ),
            ),
          ),
        ),
        title: Text(
          'edit_profile_title'.tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 14, right: 14, bottom: 30, top: 30),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Obx(() {
                    return Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(width: 2, color: Colors.white),
                        image: DecorationImage(
                          image:
                              controller.profileImage.value != null
                                  ? FileImage(controller.profileImage.value!)
                                  : (controller.networkImage.value != null &&
                                      controller.networkImage.value!.isNotEmpty)
                                  ? NetworkImage(controller.networkImage.value!)
                                  : AssetImage(IconsPath.profileAvater)
                                      as ImageProvider,
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  }),
                  Positioned(
                    bottom: 6,
                    right: 2,
                    child: GestureDetector(
                      onTap: controller.pickImage,
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Image.asset(IconsPath.editIcon, height: 30),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 24),
            CustomTextField(
              hintText: 'name'.tr,
              controller: controller.nameController,
            ),
            SizedBox(height: 15),
            CustomTextField(
              hintText: 'email'.tr,
              controller: controller.emailController,
              readOnly: true,
            ),
            Spacer(),
            CustomButtom(
              text: 'save'.tr,
              ontap: () {
                controller.updateProfile();
              },
            ),
            SizedBox(height: 14),
            CustomButtom(
              buttonColor: Colors.white.withValues(alpha: 0.06),
              textColor: Colors.white,
              text: 'cancel'.tr,
              ontap: () {
                Get.back();
              },
            ),
          ],
        ),
      ),
    );
  }
}
