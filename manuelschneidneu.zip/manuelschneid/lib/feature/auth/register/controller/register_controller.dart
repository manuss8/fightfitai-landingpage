import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/feature/auth/register/view/apply_here_view.dart';
import 'package:manuelschneid/route/app_route.dart';

class RegisterController extends GetxController {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String? otpController = "";

  var isPassWordVisible = true.obs;

  RxInt remainingSeconds = 120.obs;
  Timer? _timer;

  @override
  void onInit() {
    super.onInit();
    startTimer();
  }

  void togglePasswordVisibility() {
    isPassWordVisible.value = !isPassWordVisible.value;
  }

  // timer method.....
  String get formattedTime {
    int seconds = remainingSeconds.value;
    return '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  }

  void startTimer() {
    _timer?.cancel();
    remainingSeconds.value = 120;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (remainingSeconds.value > 0) {
        remainingSeconds.value--;
      } else {
        timer.cancel();
        update();
      }
    });
  }

  // Register user method......
  Future<void> register() async {
    String name = nameController.text.trim();
    String email = emailController.text.trim();
    String phone = phoneController.text.trim();
    String password = passwordController.text.trim();

    if (name.isEmpty) {
      EasyLoading.showToast("please_enter_your_name".tr);
      return;
    }

    if (email.isEmpty) {
      EasyLoading.showToast("please_enter_your_email_address".tr);
      return;
    } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      EasyLoading.showToast("please_enter_a_valid_email_address".tr);
      return;
    }

    if (password.isEmpty) {
      EasyLoading.showToast("please_enter_your_password".tr);
      return;
    } else if (password.length < 8) {
      EasyLoading.showToast("password_must_be_at_least_8_characters_long".tr);
      return;
    }

    try {
      EasyLoading.show(status: "loading".tr);
      String url = Urls.register;

      var response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "userName": name,
          "email": email,
          "phoneNumber": phone,
          "password": password,
        }),
      );

      log("Response Urls: $url");
      log("Response status code: ${response.statusCode}");
      log("Response body: ${response.body}");

      var responseData = jsonDecode(response.body);
      if (response.statusCode == 200) {
        //EasyLoading.showSuccess("Registration Successfull");
        Get.to(() => ApplyHereView());
      } else if (response.statusCode == 400) {
        EasyLoading.showError("${responseData['message']}");
      } else {
        EasyLoading.showError("failed_to_register".tr);
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  // otp verify method.......
  Future<void> verifyOtp(String email) async {
    final url = Urls.verifyOtp;

    if (kDebugMode) {
      print("Sending OTP verification for email: '$email'");
    }

    int otp = int.tryParse(otpController.toString()) ?? -1;

    if (otp < 0) {
      EasyLoading.showError("invalid_otp_please_enter_a_valid_number".tr);
      return;
    }

    try {
      EasyLoading.show(status: "loading".tr);
      final body = json.encode({"email": email, "otp": otp});

      final response = await http.post(
        Uri.parse(url),
        body: body,
        headers: {"Content-Type": "application/json"},
      );

      log("Response Urls: $url");
      log("Response Status Code: ${response.statusCode}");
      log("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);
        String accessToken = responseData["data"]["token"];
        String role = responseData["data"]["role"];

        log("Access Token: $accessToken");
        log("User Role: $role");

        await SharePref.saveToken(accessToken);
        await SharePref.saveRole(role);

        // ✅ Navigate based on role
        if (role == "USER") {
          Get.offAllNamed(AppRoute.bottomNavbarScreen);
        } else {
          Get.offAllNamed(AppRoute.adminProfile);
        }

        //Get.offAllNamed('/signinScreen');
      } else {
        EasyLoading.showError("failed_to_verify_otp".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  // resend otp method.......
  Future<void> resendOTP() async {
    EasyLoading.show(status: "Loading".tr);
    final url = Urls.resendOTP;

    final body = json.encode({"email": emailController.text.trim()});

    try {
      final response = await http.post(
        Uri.parse(url),
        body: body,
        headers: {"Content-Type": "application/json"},
      );

      log('Response URL: $url');
      log('Response  Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        startTimer();
      } else {
        EasyLoading.showError("failed_to_resend_otp_verification".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  @override
  void onClose() {
    _timer?.cancel();
    super.onClose();
  }
}
