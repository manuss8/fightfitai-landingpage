import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:manuelschneid/core/const/background_path.dart';
import 'package:manuelschneid/core/global_widegts/app_text_button.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/auth/register/controller/register_controller.dart';

class ApplyHereView extends StatelessWidget {
  ApplyHereView({super.key});

  final RegisterController controller = Get.put(RegisterController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(BackgroundImagePath.background),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.only(top: 75, left: 24, right: 24, bottom: 30),
          child: Column(
            children: [
              Text(
                "apply_here".tr,
                style: globalTextStyle(
                  color: Color(0xFFF1F2F6),
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "start_your_journey_to_mastering_money_with_fun_interactive_lessons_today!"
                    .tr,
                textAlign: TextAlign.center,
                style: globalTextStyle(color: Color(0xFF7E7D7C), fontSize: 12),
              ),
              SizedBox(height: 20),
              OtpTextField(
                numberOfFields: 4,
                borderColor: Color(0xFFE5E7EB).withValues(alpha: 0.1),
                fillColor: Color(0xFFFFFFFF),
                textStyle: TextStyle(
                  fontSize: 24,
                  color: Color(0xFFFFFFFF),
                  fontWeight: FontWeight.bold,
                ),
                borderRadius: BorderRadius.circular(16),
                onSubmit: (value) {
                  controller.otpController = value;
                },
                fieldWidth: 60,
                borderWidth: 2,
                contentPadding: EdgeInsets.symmetric(
                  vertical: 10,
                  horizontal: 15,
                ),
                showFieldAsBox: true,
              ),
              SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Obx(() {
                    final canResend = controller.remainingSeconds.value == 0;
                    return AppTextButton(
                      text: "resend_code_in".tr,
                      onTap:
                          canResend
                              ? () {
                                controller.resendOTP();
                                controller.startTimer();
                              }
                              : () {},
                      textColor: canResend ? Colors.grey : Colors.grey,
                      textSize: 14,
                      fontWeight: canResend ? FontWeight.bold : FontWeight.w400,
                      textDecoration:
                          canResend ? TextDecoration.underline : null,
                    );
                  }),
                  Obx(() {
                    return Text(
                      " ${controller.formattedTime}",
                      style: globalTextStyle(
                        color: Colors.grey,
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                      ),
                    );
                  }),
                ],
              ),
              Spacer(),
              CustomButtom(
                text: "apply_code".tr,
                ontap: () {
                  controller.verifyOtp(controller.emailController.text);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
