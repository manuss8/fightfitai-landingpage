import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show TextEditingController;
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/auth/forget_password/view/otp_verification_view.dart';
import 'package:manuelschneid/feature/auth/forget_password/view/reset_password_view.dart';
import 'package:manuelschneid/route/app_route.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ForgetPasswordController extends GetxController {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  String? otpController = "";

  var isNewPassword = true.obs;
  var isConfirmPassword = true.obs;

  RxInt remainingSeconds = 120.obs;
  Timer? _timer;

  @override
  void onInit() {
    super.onInit();
    startTimer();
  }

  void toggleNewPassword() {
    isNewPassword.value = !isNewPassword.value;
  }

  void toggleRePassword() {
    isConfirmPassword.value = !isConfirmPassword.value;
  }

  // timer method.....
  String get formattedTime {
    int seconds = remainingSeconds.value;
    return '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  }

  void startTimer() {
    _timer?.cancel();
    remainingSeconds.value = 120;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (remainingSeconds.value > 0) {
        remainingSeconds.value--;
      } else {
        timer.cancel();
        update();
      }
    });
  }

  // forget password method.......
  Future<void> forgetPassword() async {
    EasyLoading.show(status: "Loading".tr);
    String url = Urls.forgetPassword;
    String email = emailController.text.trim();

    if (kDebugMode) {
      print("Email: $email");
    }

    if (email.isEmpty) {
      EasyLoading.showError("please_enter_your_email_address".tr);
      return;
    }

    try {
      var response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": email}),
      );

      log("Response Urls: $url");
      log("Response Status Code: ${response.statusCode}");
      log("Response Body: ${response.body}");

      var responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        //EasyLoading.showSuccess("Forget password is Successfull.");
        Get.to(() => OtpVerificationView());
      } else {
        if (kDebugMode) {
          print("Error: $responseData");
        }
        EasyLoading.showError("failed_to_forget_password".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  // otp verify method.......
  Future<void> verifyOtpApiCall(String email) async {
    final url = Urls.verifyOtp;

    if (kDebugMode) {
      print("Sending OTP verification for email: '$email'");
    }

    int otp = int.tryParse(otpController.toString()) ?? -1;

    if (otp < 0) {
      EasyLoading.showError("invalid_otp_please_enter_a_valid_number".tr);
      return;
    }

    try {
      EasyLoading.show(status: "loading".tr);
      final body = json.encode({"email": email, "otp": otp});

      final response = await http.post(
        Uri.parse(url),
        body: body,
        headers: {"Content-Type": "application/json"},
      );

      log("Response Urls: $url");
      log("Response Status Code: ${response.statusCode}");
      log("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        Get.to(() => ResetPasswordView());
      } else {
        EasyLoading.showError("failed_to_verify_otp".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  // Reset password method.......
  Future<void> resetPassword() async {
    EasyLoading.show(status: "Loading".tr);
    final url = Urls.resetPassword;

    String newPassword = newPasswordController.text.trim();
    String confirmPassword = confirmPasswordController.text.trim();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    if (newPassword.isEmpty) {
      EasyLoading.showToast("please_enter_a_new_password".tr);
      return;
    } else if (newPassword.length < 8) {
      EasyLoading.showToast("Password must be at least 8 characters long".tr);
      return;
    }
    if (newPassword == confirmPassword) {
      try {
        final body = json.encode({
          "email": emailController.text.trim(),
          "password": newPassword,
        });

        final response = await http.post(
          Uri.parse(url),
          body: body,
          headers: {
            "Content-Type": "application/json",
            "Authorization": "$token",
          },
        );

        log('Response URL: $url');
        log('Response Status code: ${response.statusCode}');
        log('Response Body: ${response.body}');

        if (response.statusCode == 200) {
          //EasyLoading.showSuccess("Password reset successfully.");
          Get.toNamed(AppRoute.signinScreen);
        } else {
          EasyLoading.showError("failed_to_reset_password".tr);
        }
      } catch (e) {
        log("Unexpected error: $e");
      } finally {
        EasyLoading.dismiss();
      }
    } else {
      EasyLoading.showError("the_password_does_not_match".tr);
    }
  }

  // resend otp method.......
  Future<void> resendOTP() async {
    EasyLoading.show(status: "Loading".tr);
    final url = Urls.resendOTP;

    final body = json.encode({"email": emailController.text.trim()});

    try {
      final response = await http.post(
        Uri.parse(url),
        body: body,
        headers: {"Content-Type": "application/json"},
      );

      log('Response URL: $url');
      log('Response  Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      if (response.statusCode == 200) {
        startTimer();
      } else {
        EasyLoading.showError("failed_to_resend_otp_verification".tr);
      }
    } catch (e) {
      log("Unexpected error: $e");
    } finally {
      EasyLoading.dismiss();
    }
  }

  @override
  void onClose() {
    _timer?.cancel();
    super.onClose();
  }
}
