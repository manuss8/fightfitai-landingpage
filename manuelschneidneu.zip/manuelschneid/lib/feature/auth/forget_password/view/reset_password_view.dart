import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/image_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart'
    show globalTextStyle;
import 'package:manuelschneid/feature/auth/forget_password/controller/forget_password_controller.dart';

class ResetPasswordView extends StatelessWidget {
  ResetPasswordView({super.key});

  final ForgetPasswordController controller = Get.put(
    ForgetPasswordController(),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: AppColors.appBackgroundColor,
      body: Padding(
        padding: EdgeInsets.only(top: 75, left: 24, right: 24, bottom: 30),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: CircleAvatar(
                      radius: 21,
                      backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
                      child: Center(
                        child: Icon(
                          Icons.arrow_back_ios_new,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 30),
                  Text(
                    "reset_password".tr,
                    style: globalTextStyle(
                      color: Color(0xFFF1F2F6),
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),

              SizedBox(height: 10),
              Text(
                "start_your_journey_to_mastering_money_with_fun_interactive_lessons_today!"
                    .tr,
                textAlign: TextAlign.center,
                style: globalTextStyle(color: Color(0xFF7E7D7C), fontSize: 12),
              ),
              SizedBox(height: 20),
              Obx(
                () => CustomTextField(
                  isObscure: controller.isNewPassword.value,
                  controller: controller.newPasswordController,
                  hintText: "new_password".tr,
                  suffixIcon: IconButton(
                    icon: Icon(
                      controller.isNewPassword.value
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Color(0xFF7E7D7C),
                    ),
                    onPressed: () {
                      controller.toggleNewPassword();
                    },
                  ),
                ),
              ),
              SizedBox(height: 15),
              Obx(
                () => CustomTextField(
                  isObscure: controller.isConfirmPassword.value,
                  controller: controller.confirmPasswordController,
                  hintText: "confirm_password".tr,
                  suffixIcon: IconButton(
                    icon: Icon(
                      controller.isNewPassword.value
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Color(0xFF7E7D7C),
                    ),
                    onPressed: () {
                      controller.toggleRePassword();
                    },
                  ),
                ),
              ),
              SizedBox(height: 50),
              Image.asset(ImagePath.appImage, width: 242, height: 296),
              SizedBox(height: MediaQuery.of(context).size.height * 0.15),
              CustomButtom(
                text: "reset_password".tr,
                ontap: () {
                  controller.resetPassword();
                  //Get.offAllNamed('/signinScreen');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
