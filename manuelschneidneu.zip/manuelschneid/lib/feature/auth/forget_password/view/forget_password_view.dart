import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/background_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/auth/forget_password/controller/forget_password_controller.dart';

class ForgetPasswordView extends StatelessWidget {
  ForgetPasswordView({super.key});

  final ForgetPasswordController controller = Get.put(
    ForgetPasswordController(),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(BackgroundImagePath.forgetPasswordemail),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.only(top: 75, left: 24, right: 24, bottom: 30),
          child: Column(
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: CircleAvatar(
                      radius: 21,
                      backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
                      child: Center(
                        child: Icon(
                          Icons.arrow_back_ios_new,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 30),
                  Text(
                    "forget_password".tr,
                    style: globalTextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 15),
              Text(
                "start_your_journey_to_mastering_money_with_fun_interactive_lessons_today!"
                    .tr,
                textAlign: TextAlign.center,
                style: globalTextStyle(color: Color(0xFF7E7D7C), fontSize: 12),
              ),
              SizedBox(height: 20),
              CustomTextField(
                controller: controller.emailController,
                hintText: "email".tr,
              ),
              Spacer(),
              CustomButtom(
                text: "continue".tr,
                ontap: () {
                  controller.forgetPassword();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
