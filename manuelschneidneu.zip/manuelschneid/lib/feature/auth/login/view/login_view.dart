import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/image_path.dart' show ImagePath;
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_text_field.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/auth/forget_password/view/forget_password_view.dart';
import 'package:manuelschneid/feature/auth/login/controller/login_controller.dart'
    show LoginController;
import 'package:url_launcher/url_launcher.dart';

class LoginView extends StatelessWidget {
  LoginView({super.key});

  final LoginController controller = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: AppColors.appBackgroundColor,

      body: Padding(
        padding: const EdgeInsets.only(
          top: 70,
          left: 20,
          right: 20,
          bottom: 30,
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Image.asset(ImagePath.appImage, width: 86, height: 95),
                SizedBox(height: 10),
                Text(
                  "login_here".tr,
                  style: globalTextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "start_your_journey_to_mastering_money_with_fun_interactive_lessons_today!"
                      .tr,
                  textAlign: TextAlign.center,
                  style: globalTextStyle(
                    color: Color(0xFF7E7D7C),
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 20),
                CustomTextField(
                  controller: controller.emailController,
                  hintText: "email".tr,
                ),
                SizedBox(height: 15),
                Obx(
                  () => CustomTextField(
                    isObscure: controller.isPassWordVisible.value,
                    controller: controller.passwordController,
                    hintText: "password".tr,
                    suffixIcon: IconButton(
                      icon: Icon(
                        controller.isPassWordVisible.value
                            ? Icons.visibility_off
                            : Icons.visibility,
                        color: Color(0xFF7E7D7C),
                      ),
                      onPressed: () {
                        controller.togglePasswordVisibility();
                      },
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      Get.to(() => ForgetPasswordView());
                    },
                    child: Text(
                      "forget_password".tr,
                      style: globalTextStyle(color: AppColors.primaryColor),
                    ),
                  ),
                ),

                SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                // Spacer(),
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: globalTextStyle(
                      color: Color(0xFF7E7D7C),
                      fontSize: 12,
                    ),
                    children: [
                      TextSpan(text: "by_continuing_you_agree_to_the".tr),
                      TextSpan(
                        text: "terms_&_conditions".tr,
                        style: globalTextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 12,
                        ),
                        recognizer:
                            TapGestureRecognizer()
                              ..onTap = () {
                                _launchURL(
                                  "https://sites.google.com/view/fitfight/home",
                                );
                              },
                      ),
                      TextSpan(text: "and".tr),
                      TextSpan(
                        text: "privacy_policy.".tr,
                        style: globalTextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 12,
                        ),
                        recognizer:
                            TapGestureRecognizer()
                              ..onTap = () {
                                _launchURL(
                                  "https://sites.google.com/view/fitfight/home",
                                );
                              },
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 14),
                CustomButtom(
                  text: "login".tr,
                  ontap: () {
                    //controller.checkUserType();
                    controller.loginApiCall();
                  },
                ),
                SizedBox(height: 14),
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: globalTextStyle(
                      color: Color(0xFF8C8482),
                      fontSize: 14,
                    ),
                    children: [
                      TextSpan(text: "don’t_have_an_account".tr),
                      TextSpan(
                        text: "sign_up".tr,
                        style: globalTextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 14,
                        ),
                        recognizer:
                            TapGestureRecognizer()
                              ..onTap = () {
                                Get.toNamed("/signupScreen");
                              },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void _launchURL(String url) async {
  final uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  } else {
    // Handle error: could not launch URL
    print('Could not launch $url');
  }
}
