import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/core/services_class/local_service/shared_preferences_helper.dart';
import 'package:manuelschneid/route/app_route.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class LoginController extends GetxController {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  var isPassWordVisible = true.obs;
  String? fcmToken;

  void togglePasswordVisibility() {
    isPassWordVisible.value = !isPassWordVisible.value;
  }

  // Register user method......
  Future<void> loginApiCall() async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty) {
      EasyLoading.showToast("please_enter_your_email_address".tr);
      return;
    } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      EasyLoading.showToast("please_enter_a_valid_email_address".tr);
      return;
    }

    if (password.isEmpty) {
      EasyLoading.showToast("please_enter_your_password".tr);
      return;
    } else if (password.length < 8) {
      EasyLoading.showToast("password_must_be_at_least_8_characters_long".tr);
      return;
    }

    try {
      EasyLoading.show(status: "loading".tr);
      String url = Urls.login;

      var response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email,
          "password": password,
          "fcmToken": fcmToken ?? "",
        }),
      );

      log("Response Urls: $url");
      log("Response status code: ${response.statusCode}");
      log("Response body: ${response.body}");

      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);
        String accessToken = responseData["data"]["token"];
        String role = responseData["data"]["role"];

        log("Access Token: $accessToken");
        log("User Role: $role");

        await SharePref.saveToken(accessToken);
        await SharePref.saveRole(role);

        if (role == "USER") {
          Get.offAllNamed(AppRoute.bottomNavbarScreen);
        } else {
          Get.offAllNamed(AppRoute.adminProfile);
        }
      } else {
        // Show error from API response
        String errorMessage;
        try {
          var errorResponse = jsonDecode(response.body);
          errorMessage =
              errorResponse['message'] ?? "login_failed. please_try_again.".tr;
        } catch (_) {
          errorMessage = "login_failed. please_try_again.".tr;
        }
        EasyLoading.showToast(errorMessage);
      }
    } on SocketException {
      log("No Internet connection");
      EasyLoading.showError(
        "no_internet_connection. please_check_your_network.".tr,
      );
    } on TimeoutException {
      log("Request timed out");
      EasyLoading.showError(
        "server_is_taking_too_long_to_respond. please_try_again_later.".tr,
      );
    } catch (e) {
      if (kDebugMode) {
        print("Error: $e");
      }
    } finally {
      EasyLoading.dismiss();
    }
  }

  @override
  void onInit() {
    super.onInit();
    _initFirebaseMessaging();
  }

  Future<void> _initFirebaseMessaging() async {
    final settings = await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus != AuthorizationStatus.authorized) {
      if (kDebugMode) {
        print('❌ Notification permission not granted');
      }
      return;
    }

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
          alert: true,
          badge: true,
          sound: true,
        );

    if (defaultTargetPlatform == TargetPlatform.iOS) {
      String? apnsToken;
      while (apnsToken == null) {
        apnsToken = await FirebaseMessaging.instance.getAPNSToken();
        await Future.delayed(const Duration(milliseconds: 100));
      }
      if (kDebugMode) {
        print('🔑 APNs token ready');
      }
    }

    // Step 4: Get the FCM token
    fcmToken = await FirebaseMessaging.instance.getToken() ?? '';
    if (kDebugMode) {
      print('🎯 FCM Token: $fcmToken');
    }

    // Step 5: Initialize local notifications
    _initLocalNotifications();

    // Step 6: Listen to foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (kDebugMode) {
        print('📨 Foreground message received: ${message.notification?.title}');
      }
      _showLocalNotification(message);
    });
  }

  void _initLocalNotifications() {
    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );
    const iOSSettings = DarwinInitializationSettings();
    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iOSSettings,
    );

    flutterLocalNotificationsPlugin.initialize(initSettings);
  }

  void _showLocalNotification(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;

    const androidDetails = AndroidNotificationDetails(
      'default_channel',
      'Default',
      channelDescription: 'Shows notifications while app is in foreground',
      importance: Importance.max,
      priority: Priority.high,
    );

    const iOSDetails = DarwinNotificationDetails();

    const platformDetails = NotificationDetails(
      android: androidDetails,
      iOS: iOSDetails,
    );

    flutterLocalNotificationsPlugin.show(
      notification.hashCode,
      notification.title,
      notification.body,
      platformDetails,
    );
  }
}
