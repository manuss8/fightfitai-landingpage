import 'dart:convert';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';
import 'package:manuelschneid/feature/notification/model/notification_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationController extends GetxController {
  var notifications = <NotificationModel>[].obs;
  final RxBool isLoading = false.obs; // Add this line
  final RxBool hasNewNotification = false.obs;

  final RxSet<String> readNotificationIds = <String>{}.obs;

  @override
  void onInit() {
    super.onInit();
    loadReadNotifications();
    fetchNotifications();
  }

  Future<void> loadReadNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList('readNotifications') ?? [];
    // ignore: invalid_use_of_protected_member
    readNotificationIds.value = ids.toSet();
  }

  Future<void> saveReadNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'readNotifications',
      readNotificationIds.toList(),
    );
  }

  Future<void> fetchNotifications() async {
    isLoading.value = true;
    // EasyLoading.show(status: "loading".tr);
    final url = "${Urls.baseUrl}/notifications";

    SharedPreferences preferences = await SharedPreferences.getInstance();
    var token = preferences.getString('token');

    try {
      var response = await http.get(
        Uri.parse(url),
        headers: {
          "Content-Type": "application/json",
          "Authorization": token ?? "",
        },
      );

      log('Request URL: $url');
      log('Status code: ${response.statusCode}');
      log('Response body: ${response.body}');

      // Modify the fetchNotifications success block
      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);
        notifications.value =
            (decodedData['data'] as List)
                .map((e) => NotificationModel.fromJson(e))
                .toList();

        // Add this block to sync with stored read status
        for (final notification in notifications) {
          notification.isRead = readNotificationIds.contains(notification.id);
        }

        hasNewNotification.value = notifications.any((n) => !n.isRead);
        // EasyLoading.showSuccess("notifications_fetched_successfully.".tr);
      } else {
        EasyLoading.showError("failed_to_fetch_notifications.".tr);
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    } finally {
      isLoading.value = false;
      EasyLoading.dismiss();
    }
  }

  // Toggle the read/unread status of a notification
  void toggleNotificationReadStatus(int index) {
    var notification = notifications[index];
    notification.isRead = !notification.isRead;

    if (notification.isRead) {
      readNotificationIds.add(notification.id);
    } else {
      readNotificationIds.remove(notification.id);
    }
    saveReadNotifications();

    notifications.refresh();
    hasNewNotification.value = notifications.any((n) => !n.isRead);
  }

  // Call this method when a new notification arrives
  // Add in NotificationController
  void onNewNotification(NotificationModel newNotification) {
    if (readNotificationIds.contains(newNotification.id)) {
      newNotification.isRead = true;
    } else {
      hasNewNotification.value = true;
    }
    notifications.insert(0, newNotification);
    notifications.refresh();
  }
}
