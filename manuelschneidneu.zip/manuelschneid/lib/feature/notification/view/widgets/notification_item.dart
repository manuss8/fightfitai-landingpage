import 'package:flutter/material.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_text.dart';
import 'package:manuelschneid/feature/notification/model/notification_model.dart';

class NotificationItem extends StatelessWidget {
  final NotificationModel notification;
  final VoidCallback onTap;

  const NotificationItem({
    super.key,
    required this.notification,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(IconsPath.upgrade, height: 35, width: 35),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 250,
                        child: CustomText(
                          maxLines: 1,
                          textOverflow: TextOverflow.ellipsis,
                          text: notification.title,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      CustomText(
                        text: notification.time,
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: Colors.grey,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 260,
                        child: CustomText(
                          text: notification.message,
                          fontSize: 14,
                          maxLines: 2,
                          textOverflow: TextOverflow.ellipsis,
                          fontWeight: FontWeight.w400,
                          color: Color(0xff939393),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 2, right: 2),
                        child: Icon(
                          Icons.circle,
                          size: 12,
                          color:
                              notification.isStatus == "Unread"
                                  ? AppColors.primaryColor
                                  : Colors.transparent,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Divider(color: Color(0xffDFE1E7), thickness: 1),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
