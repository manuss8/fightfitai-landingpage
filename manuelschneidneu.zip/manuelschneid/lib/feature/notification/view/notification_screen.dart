import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/global_widegts/custom_text.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/notification/controller/notification_controller.dart';
import 'package:manuelschneid/feature/notification/view/widgets/notification_item.dart';
import 'package:manuelschneid/feature/notification/view/widgets/notification_item_shimmar.dart';

class NotificationScreen extends StatelessWidget {
  final NotificationController controller = Get.put(NotificationController());

  NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchNotifications();
      controller.hasNewNotification.value = false;
    });

    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
              child: Center(
                child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
              ),
            ),
          ),
        ),
        title: Text(
          "notification".tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 16, right: 31),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: RefreshIndicator(
                onRefresh: () async {
                  await controller.fetchNotifications();
                },
                child: Obx(
                  () =>
                      controller.isLoading.value
                          ? ListView.builder(
                            itemCount: 6,
                            itemBuilder:
                                (context, index) => NotificationItemShimmer(),
                          )
                          : controller.notifications.isEmpty
                          ? Center(
                            child: CustomText(
                              text: "no_notifications".tr,
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                            ),
                          )
                          : ListView.builder(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: EdgeInsets.all(0),
                            itemCount: controller.notifications.length,
                            itemBuilder: (context, index) {
                              final notification =
                                  controller.notifications[index];
                              return NotificationItem(
                                notification: notification,
                                onTap: () {
                                  controller.toggleNotificationReadStatus(
                                    index,
                                  );
                                },
                              );
                            },
                          ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
