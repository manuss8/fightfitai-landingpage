class NotificationModel {
  final String id;
  final String title;
  final String body;
  bool isRead;
  final DateTime createdAt;
  final Sender sender;

  NotificationModel({
    required this.id,
    required this.title,
    required this.body,
    this.isRead = false,
    required this.createdAt,
    required this.sender,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      body: json['body'] ?? '',
      isRead: json['isRead'] ?? false,
      createdAt: DateTime.parse(json['createdAt']),
      sender: Sender.fromJson(json['sender']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'isRead': isRead,
      'createdAt': createdAt.toIso8601String(),
      'sender': sender.toJson(),
    };
  }

  // Helpers
  String get time =>
      "${createdAt.hour}:${createdAt.minute.toString().padLeft(2, '0')}";
  String get message => body;
  String get isStatus => isRead ? "Read" : "Unread";
}

class Sender {
  final String id;
  final String phoneNumber;
  final String? profileImage;

  Sender({required this.id, required this.phoneNumber, this.profileImage});

  factory Sender.fromJson(Map<String, dynamic> json) {
    return Sender(
      id: json['id'] ?? '',
      phoneNumber: json['phoneNumber'] ?? '',
      profileImage: json['profileImage'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'id': id, 'phoneNumber': phoneNumber, 'profileImage': profileImage};
  }
}
