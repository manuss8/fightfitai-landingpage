// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:manuelschneid/core/const/bottom_navbar_image_path.dart'
//     show BottomNavbarImagePath;

// import 'package:manuelschneid/feature/bottom_navbar/controller/bottom_navbar_controller.dart'
//     show BottomNavbarController;

// class BottomNavbarView extends StatelessWidget {
//   BottomNavbarView({super.key});

//   final BottomNavbarController controller = Get.put(BottomNavbarController());

//   final List<Map<String, String>> navItems = [
//     {
//       'active': BottomNavbarImagePath.activeHome,
//       'inactive': BottomNavbarImagePath.inactiveHome,
//     },
//     {
//       'active': BottomNavbarImagePath.activeTraining,
//       'inactive': BottomNavbarImagePath.inactiveTraining,
//     },
//     {
//       'active': BottomNavbarImagePath.activeCoach,
//       'inactive': BottomNavbarImagePath.inactiveCoach,
//     },
//     {
//       'active': BottomNavbarImagePath.activeGoal,
//       'inactive': BottomNavbarImagePath.inactiveGoal,
//     },
//     {
//       'active': BottomNavbarImagePath.activeNeut,
//       'inactive': BottomNavbarImagePath.inactiveNeut,
//     },
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children: [
//           Positioned.fill(child: Obx(() => controller.getCurrentScreen())),
//           Positioned(
//             bottom: 30, // Keep it at the same position
//             left: 0,
//             right: 0,
//             child: Center(
//               child: Obx(
//                 () => ClipRRect(
//                   borderRadius: BorderRadius.circular(79),
//                   child: Container(
//                     width: MediaQuery.of(context).size.width * 0.9,
//                     height: 65,
//                     decoration: BoxDecoration(
//                       color: Colors.transparent, // Make background transparent
//                       borderRadius: BorderRadius.circular(79),
//                     ),
//                     child: Container(
//                       decoration: BoxDecoration(
//                         color: const Color(
//                           0xFF313131,
//                         ), // Apply color only inside navbar
//                         borderRadius: BorderRadius.circular(79),
//                       ),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceAround,
//                         children: List.generate(navItems.length, (index) {
//                           return GestureDetector(
//                             onTap: () => controller.changeTab(index),
//                             child: Padding(
//                               padding: const EdgeInsets.all(5),
//                               child: Image.asset(
//                                 controller.selectedIndex.value == index
//                                     ? navItems[index]['active']!
//                                     : navItems[index]['inactive']!,
//                                 width:
//                                     controller.selectedIndex.value == index
//                                         ? 100
//                                         : 44,
//                               ),
//                             ),
//                           );
//                         }),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// Actual this code is final ...............!!
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/bottom_navbar_image_path.dart'
    show BottomNavbarImagePath;
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/bottom_navbar/controller/bottom_navbar_controller.dart'
    show BottomNavbarController;

class BottomNavbarView extends StatelessWidget {
  BottomNavbarView({super.key});

  final BottomNavbarController controller = Get.put(BottomNavbarController());

  final List<Map<String, String>> navItems = [
    {
      'active': IconsPath.activeHome,
      'inactive': BottomNavbarImagePath.inactiveHome,
    },
    {
      'active': IconsPath.activeTraining,
      'inactive': BottomNavbarImagePath.inactiveTraining,
    },
    {
      'active': IconsPath.activeCoach,
      'inactive': BottomNavbarImagePath.inactiveCoach,
    },
    {
      'active': IconsPath.activeGoal,
      'inactive': BottomNavbarImagePath.inactiveGoal,
    },
    {
      'active': IconsPath.activeNeut,
      'inactive': BottomNavbarImagePath.inactiveNeut,
    },
  ];

  // final List<String> navItemsName = [
  //   "home".tr,
  //   "training".tr,
  //   "coach".tr,
  //   "plan".tr,
  //   "nutrition".tr,
  // ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Obx(() => controller.getCurrentScreen())),
          Positioned(
            bottom: 30,
            left: 0,
            right: 0,
            child: Center(
              child: Obx(
                () => ClipRRect(
                  borderRadius: BorderRadius.circular(79),
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.94,
                    height: 65,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(79),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF313131),
                        borderRadius: BorderRadius.circular(79),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: List.generate(navItems.length, (index) {
                          final isSelected =
                              controller.selectedIndex.value == index;

                          final navItemName =
                              [
                                "home".tr,
                                "training".tr,
                                "coach".tr,
                                "plan".tr,
                                "nutrition".tr,
                              ][index];

                          return GestureDetector(
                            onTap: () => controller.changeTab(index),
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color:
                                      isSelected
                                          ? AppColors.primaryColor
                                          : Colors.transparent,
                                  borderRadius: BorderRadius.circular(50),
                                ),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      isSelected
                                          ? navItems[index]['active']!
                                          : navItems[index]['inactive']!,
                                      height: isSelected ? 25 : 33,
                                      width: isSelected ? 25 : 33,
                                    ),
                                    const SizedBox(width: 4),
                                    if (isSelected)
                                      Text(
                                        navItemName,
                                        style: globalTextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
