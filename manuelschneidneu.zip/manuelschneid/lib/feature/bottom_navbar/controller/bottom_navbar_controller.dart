import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/feature/coach/view/coach_view.dart'
    show CoachView;
import 'package:manuelschneid/feature/goal/goal_list/view/goal_view.dart'
    show GoalView;
import 'package:manuelschneid/feature/home/home_data/view/home_view.dart'
    show HomeView;
import 'package:manuelschneid/feature/home/see_all_training_category/view/see_all_training_category_view.dart'
    show SeeAllTrainingCategoryView;
import 'package:manuelschneid/feature/neutrition/neut_list/view/nutrition_view.dart';

class BottomNavbarController extends GetxController {
  var selectedIndex = 0.obs;

  void changeTab(int index) {
    selectedIndex.value = index;
  }

  Widget getCurrentScreen() {
    switch (selectedIndex.value) {
      case 0:
        return HomeView();
      case 1:
        return SeeAllTrainingCategoryView();
      case 2:
        return CoachView();
      case 3:
        return GoalView();
      case 4:
        return NutritionView();

      default:
        return HomeView();
    }
  }
}
