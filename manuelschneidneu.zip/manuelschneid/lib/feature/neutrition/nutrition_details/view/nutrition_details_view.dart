import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/neutrition/nutrition_details/controller/nutrition_details_controller.dart';
import 'package:url_launcher/url_launcher.dart';

class NutritionDetailsView extends StatelessWidget {
  NutritionDetailsView({super.key});

  final NutritionDetailsController controller = Get.put(
    NutritionDetailsController(),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        title: Obx(
          () => Text(
            controller.selectedNutritionPlan.value?.data.title ??
                "nutrition_plan".tr,
            style: globalTextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFFF1F2F6),
            ),
          ),
        ),
        centerTitle: true,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Colors.white.withOpacity(0.1),
              child: Icon(
                Icons.arrow_back_ios_new,
                color: Colors.white,
                size: 16,
              ),
            ),
          ),
        ),
      ),
      body: Obx(() {
        final plan = controller.selectedNutritionPlan.value;

        if (plan == null) {
          return Center(child: CircularProgressIndicator());
        }

        return ListView(
          padding: EdgeInsets.all(20),
          children: [
            ...plan.data.meals.map((meal) {
              final index = plan.data.meals.indexOf(meal);
              final isExpanded = controller.isExpandedList[index];

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                  border:
                      isExpanded ? Border.all(color: Colors.transparent) : null,
                ),
                child: ExpansionTile(
                  initiallyExpanded: isExpanded,
                  tilePadding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 5,
                  ),
                  childrenPadding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 15,
                  ),
                  collapsedBackgroundColor: Colors.transparent,
                  backgroundColor: Colors.transparent,
                  iconColor: Colors.white,
                  collapsedIconColor: Colors.white,
                  onExpansionChanged: (expanded) {
                    controller.toggleExpanded(index);
                  },
                  title: Text(
                    meal.title,
                    style: globalTextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: isExpanded ? AppColors.primaryColor : Colors.white,
                    ),
                  ),
                  children:
                      meal.items.map((item) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Text(
                            "${item.name} – ${item.calories} kcal",
                            style: globalTextStyle(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        );
                      }).toList(),
                ),
              );
            }),

            // ---------- References Section ----------
            Column(
              children: [
                SizedBox(height: 20),
                Text(
                  "references".tr,
                  style: globalTextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),
                if (plan.data.references.isNotEmpty)
                  ...plan.data.references.map((ref) {
                    return GestureDetector(
                      onTap: () {
                        // Open the reference link
                        launchUrl(Uri.parse(ref));
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 6.0),
                        child: Text(
                          ref,
                          style: globalTextStyle(
                            fontSize: 14,
                            color: Colors.blueAccent,
                          ),
                        ),
                      ),
                    );
                  })
                else
                  GestureDetector(
                    onTap: () {
                      launchUrl(
                        Uri.parse(
                          "https://lifeandhealth.org/?gad_source=1&gad_campaignid=22424464928&gbraid=0AAAAAC7gUNdS6UQ-8cfwQ1aNlnAQ9OJ4Y&gclid=Cj0KCQjwrc7GBhCfARIsAHGcW5WxNAX7x25OUA-4MbrAZ7t1B1jnE39y75o3Uc5E2ClCU6Y7zMqO6H8aAlKiEALw_wcB",
                        ),
                      );
                    },
                    child: Text(
                      "lifeandhealth.org",
                      style: globalTextStyle(
                        fontSize: 14,
                        color: Colors.blueAccent,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        );
      }),
    );
  }
}
