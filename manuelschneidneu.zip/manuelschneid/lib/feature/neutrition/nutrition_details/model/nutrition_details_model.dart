class NutritionPlanResponse {
  final bool success;
  final String message;
  final NutritionPlan data;

  NutritionPlanResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  factory NutritionPlanResponse.fromJson(Map<String, dynamic> json) {
    return NutritionPlanResponse(
      success: json['success'],
      message: json['message'],
      data: NutritionPlan.fromJson(json['data']),
    );
  }
}

class NutritionPlan {
  final String id;
  final String title;
  final int calories;
  final int protein;
  final int carbs;
  final int fats;
  final List<String> references;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Meal> meals;

  NutritionPlan({
    required this.id,
    required this.title,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fats,
    required this.references,
    required this.createdAt,
    required this.updatedAt,
    required this.meals,
  });

  factory NutritionPlan.fromJson(Map<String, dynamic> json) {
    return NutritionPlan(
      id: json['id'],
      title: json['title'],
      calories: json['calories'],
      protein: json['protein'],
      carbs: json['carbs'],
      fats: json['fats'],
      references: List<String>.from(json['references']),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      meals:
          (json['meals'] as List)
              .map((mealJson) => Meal.fromJson(mealJson))
              .toList(),
    );
  }
}

class Meal {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Item> items;

  Meal({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.items,
  });

  factory Meal.fromJson(Map<String, dynamic> json) {
    return Meal(
      id: json['id'],
      title: json['title'],
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      items:
          (json['items'] as List)
              .map((itemJson) => Item.fromJson(itemJson))
              .toList(),
    );
  }
}

class Item {
  final String id;
  final String name;
  final int calories;
  final int order;

  Item({
    required this.id,
    required this.name,
    required this.calories,
    required this.order,
  });

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      id: json['id'],
      name: json['name'],
      calories: json['calories'],
      order: json['order'],
    );
  }
}
