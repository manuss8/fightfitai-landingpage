import 'package:manuelschneid/feature/neutrition/nutrition_details/model/nutrition_details_model.dart';

class NutritionPlan {
  final String id;
  final String? userId; // Can be null as shown in your API response
  final String title;
  final List<String> references; // New field from API
  final int calories;
  final int protein;
  final int carbs;
  final int fats;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Meal> meals;

  NutritionPlan({
    required this.id,
    this.userId,
    required this.title,
    this.references = const [],
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fats,
    required this.createdAt,
    required this.updatedAt,
    this.meals = const [],
  });

  factory NutritionPlan.fromJson(Map<String, dynamic> json) {
    return NutritionPlan(
      id: json['id'],
      userId: json['userId'], // Can be null
      title: json['title'],
      references: (json['references'] as List?)?.cast<String>() ?? [],
      calories: json['calories'],
      protein: json['protein'],
      carbs: json['carbs'],
      fats: json['fats'],
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      meals:
          (json['meals'] as List?)
              ?.map((mealJson) => Meal.fromJson(mealJson))
              .toList() ??
          [],
    );
  }
}
