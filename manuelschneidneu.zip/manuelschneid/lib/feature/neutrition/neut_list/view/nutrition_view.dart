import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart' show AppColors;
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/neutrition/neut_list/controller/neut_controller.dart';
import 'package:manuelschneid/feature/neutrition/neut_list/widgets/ai_nutrition_list_bottom_sheet.dart'
    show showNeutrionPlanInputBottomSheet;
import 'package:manuelschneid/feature/neutrition/neut_list/widgets/nutrition_list.dart';

class NutritionView extends StatelessWidget {
  NutritionView({super.key});

  final NeutController controller = Get.put(NeutController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        title: Text(
          "ai_nutrition_plan".tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: GestureDetector(
              onTap: () {
                showNeutrionPlanInputBottomSheet(context);
              },
              child: CircleAvatar(
                radius: 21,
                backgroundColor: Colors.white.withValues(alpha: 0.1),
                child: Center(child: Icon(Icons.add, color: Colors.white)),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 5, bottom: 120),
        child: Column(
          children: [SizedBox(height: 15), Expanded(child: NutritionList())],
        ),
      ),
    );
  }
}
