import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/image_path.dart'; // Assuming ImagePath.aiq1 is the desired image
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/global_widegts/custom_dropdown_widget.dart'
    show CustomDropdown;
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/neutrition/neut_list/controller/neut_controller.dart';

Widget _buildBottomSheetContent({
  required BuildContext context,
  required String specificQuestion,
  required Widget inputWidget,
  required String buttonText,
  required VoidCallback onButtonPressed,
  required String imagePath, // Allow specifying image if they are different
}) {
  return Padding(
    padding: MediaQuery.of(context).viewInsets, // Adjust for keyboard
    child: SingleChildScrollView(
      child: IntrinsicHeight(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min, // Fit content height
            children: [
              Text(
                "customize_your_training_plan_based_on_your_fitness_level".tr,
                textAlign: TextAlign.center,
                style: globalTextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 20),
              Image.asset(imagePath, width: 216, height: 214),
              Container(
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(40)),
                ),
                child: Text(
                  specificQuestion,
                  textAlign: TextAlign.center,
                  style: globalTextStyle(
                    fontSize: 16, // Adjust size as needed
                    fontWeight: FontWeight.w600,
                    color: Colors.black, // Adjust weight as needed
                  ),
                ),
              ),
              SizedBox(height: 10), // Space between question and input
              inputWidget,
              SizedBox(height: 50),
              CustomButtom(
                contentPadding: 16,
                text: buttonText,
                ontap: onButtonPressed,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// --- Step 1: Fitness Plan Input ---
void showNeutrionPlanInputBottomSheet(BuildContext context) {
  final NeutController controller = Get.find<NeutController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "Write here your nutrition plan ?",
          // specificQuestion: "write_here_your_nutrition_plan".tr,
          specificQuestion: "what_are_your_goals?".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: TextField(
            controller:
                controller
                    .fitnessPlanController, // Assuming you add this to NeutController
            style: globalTextStyle(color: Colors.white), // Example style
            decoration: InputDecoration(
              contentPadding: EdgeInsets.all(20),
              hintText: "write_here".tr,
              hintStyle: globalTextStyle(color: Colors.white54),
              border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white38),
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
            ),
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context); // Close current bottom sheet
            showFitnessLevelBottomSheet(context); // Show next step
          },
        ),
  );
}

// --- Step 2: Fitness Level Selection ---
void showFitnessLevelBottomSheet(BuildContext context) {
  final NeutController controller = Get.find<NeutController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "What is your current fitness level?",
          specificQuestion: "what_is_your_current_fitness_level?".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            //items: ["Beginner", "Intermediate", "Advanced"],
            items: ["beginner".tr, "intermediate".tr, "advanced".tr],
            hintText: "beginner/intermediate/advanced".tr,
            controller: controller.fitnessLevelController,
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context);
            showTrainingneutsBottomSheet(context);
          },
        ),
  );
}

// --- Step 3: Primary Training neuts Selection ---
void showTrainingneutsBottomSheet(BuildContext context) {
  final NeutController controller = Get.find<NeutController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "What are your primary training goals?",
          specificQuestion: "what_are_your_primary_training_goals?".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            //items: ["Strength", "Endurance", "Technique"],
            items: ["strength".tr, "endurance".tr, "technique".tr],
            hintText: "strength/endurance/technique".tr,
            controller: controller.primaryneutsController,
          ),
          buttonText: "next".tr,
          onButtonPressed: () {
            Navigator.pop(context);
            showTrainingDaysBottomSheet(context);
          },
        ),
  );
}

// --- Step 4: Training Days Selection ---
void showTrainingDaysBottomSheet(BuildContext context) {
  final NeutController controller = Get.find<NeutController>();

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF242424),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    isScrollControlled: true,
    builder:
        (context) => _buildBottomSheetContent(
          context: context,
          // specificQuestion: "How many days per week do you train?",
          specificQuestion: "how_many_days_per_week_do_you_train?".tr,
          imagePath: ImagePath.aiq1,
          inputWidget: CustomDropdown(
            items: [
              "0_days".tr,
              "1_days".tr,
              "2_days".tr,
              "3_days".tr,
              "4_days".tr,
              "5_days".tr,
              "6_days".tr,
              "7_days".tr,
            ],
            hintText: "0_days".tr,
            controller: controller.trainingDaysController,
          ),
          buttonText: "generate_goal".tr,
          onButtonPressed: () {
            controller.postNeut();

            Navigator.pop(context);
          },
        ),
  );
}
