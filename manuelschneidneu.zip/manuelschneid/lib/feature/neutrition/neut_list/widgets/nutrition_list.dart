import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/neutrition/containers/goal_list_containers.dart';
import 'package:manuelschneid/feature/neutrition/nutrition_details/view/nutrition_details_view.dart';
import 'package:manuelschneid/feature/neutrition/neut_list/controller/neut_controller.dart';

class NutritionList extends StatelessWidget {
  NutritionList({super.key});

  final NeutController controller = Get.find<NeutController>();

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.isLoading.value) {
        return Center(child: CircularProgressIndicator());
      }

      final plans = controller.nutritionPlanList;

      if (plans.isEmpty) {
        // return Center(
        //   child: Text(
        //     "no_data_found".tr,
        //     style: globalTextStyle(
        //       color: Colors.white54,
        //       fontSize: 16,
        //       fontWeight: FontWeight.w500,
        //     ),
        //   ),
        // );

        return Column(
          children: [
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Abnehmen & Ausdauerkraft: Dein Täglicher Ernährungsplan",
                      style: globalTextStyle(
                        color: AppColors.primaryColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 12),
                    Wrap(
                      spacing: 20,
                      runSpacing: 10,
                      children: [
                        neutListContainers(text: "Kohlenhydrate: ~200g"),
                        neutListContainers(text: "Protein: ~160g"),
                        neutListContainers(text: "Fette: ~40g"),
                        neutListContainers(text: "Kalorien: ~1800 kcal"),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      }

      return ListView.builder(
        itemCount: controller.nutritionPlanList.length,
        padding: EdgeInsets.zero,
        itemBuilder: (context, index) {
          final plan = controller.nutritionPlanList[index];

          return Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: GestureDetector(
              onTap: () {
                Get.to(() => NutritionDetailsView(), arguments: plan.id);
              },
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        plan.title,
                        style: globalTextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 12),
                      Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: [
                          neutListContainers(
                            text: "${"carbs".tr}: ~${plan.carbs}g",
                          ),
                          neutListContainers(
                            text: "Protein: ~${plan.protein}g",
                          ),
                          neutListContainers(
                            text: "${"fats".tr}: ~${plan.fats}g",
                          ),
                          neutListContainers(
                            text: "${"calories".tr}: ~${plan.calories} kcal",
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    });
  }
}
