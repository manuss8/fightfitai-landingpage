import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/image_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/coach/view/ai_coach_chat.dart';
import 'package:manuelschneid/feature/user_profile/controller/profile_controller.dart';

class CoachView extends StatelessWidget {
  CoachView({super.key});
  final UserProfileController controller = Get.find<UserProfileController>();

  @override
  Widget build(BuildContext context) {
    var userName = controller.userProfile.value?.data.userName;

    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 100),
            Align(
              alignment: Alignment.center,
              child: Image.asset(ImagePath.appImage, width: 242, height: 430),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: globalTextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                  children: [
                    TextSpan(text: "how_may_i_help_you_today".tr),
                    TextSpan(
                      text: "  $userName",
                      style: globalTextStyle(
                        color: AppColors.primaryColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 80.0),
              child: CustomButtom(
                radius: 96,
                width: double.infinity,
                contentPadding: 16,
                text: "let’s_start".tr,
                ontap: () {
                  Get.to(() => AiCoachChat());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
