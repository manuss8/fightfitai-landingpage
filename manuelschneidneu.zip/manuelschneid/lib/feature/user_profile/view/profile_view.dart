import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/user_profile/controller/profile_controller.dart';
import 'package:manuelschneid/feature/user_profile/view/change_password_view.dart';
import 'package:manuelschneid/feature/user_profile/view/edit_profile_view.dart';
import 'package:manuelschneid/feature/user_profile/view/widgets/profile_card.dart';

class UserProfileView extends StatelessWidget {
  UserProfileView({super.key});

  final UserProfileController controller = Get.put(UserProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Color(0xFFF1F2F6).withValues(alpha: 0.1),
              child: Center(
                child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
              ),
            ),
          ),
        ),
        title: Text(
          "profile".tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 60, left: 14, right: 14, bottom: 10),
          child: Column(
            children: [
              Obx(
                () => CircleAvatar(
                  radius: 50,
                  backgroundColor: AppColors.primaryColor,
                  child: CircleAvatar(
                    radius: 48,
                    backgroundImage:
                        (controller.userProfile.value?.data.profileImage !=
                                    null &&
                                controller
                                    .userProfile
                                    .value!
                                    .data
                                    .profileImage
                                    .isNotEmpty)
                            ? NetworkImage(
                              controller.userProfile.value!.data.profileImage,
                            )
                            : const AssetImage(IconsPath.profileAvater)
                                as ImageProvider,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Obx(
                () => Text(
                  controller.userProfile.value?.data.userName ?? "N/A",
                  style: globalTextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 5),
              Obx(
                () => Text(
                  controller.userProfile.value?.data.email ?? "N/A",
                  style: globalTextStyle(
                    color: Color(0xFFF1F2F6).withValues(alpha: 0.64),
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(height: 5),
              Obx(
                () => Text(
                  "${"collected_coins".tr}: ${controller.userProfile.value?.data.points ?? 0}",
                  style: globalTextStyle(
                    color: AppColors.primaryColor,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                  ),
                ),
              ),

              SizedBox(height: 40),
              // ProfileContentContainer(
              //   containerColor: Colors.white.withValues(alpha: 0.06),
              //   textColor: Colors.white,
              //   image: IconsPath.upgrade,
              //   avaterColor: AppColors.primaryColor,
              //   text: "upgrade_to_pro".tr,
              //   onTap: () {
              //     Get.to(() => UpgradeProView());
              //   },
              // ),
              SizedBox(height: 18),
              ProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.editProfile,
                avaterColor: AppColors.primaryColor,
                text: "edit_profile".tr,
                onTap: () {
                  Get.to(() => UserEditProfileView());
                },
              ),
              SizedBox(height: 18),
              ProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.lockIcon,
                avaterColor: AppColors.primaryColor,
                text: "change_password".tr,
                onTap: () {
                  Get.to(() => UserChangePasswordView());
                },
              ),
              SizedBox(height: 28),
              // ProfileContentContainer(
              //   containerColor: Colors.white.withValues(alpha: 0.06),
              //   textColor: Colors.white,
              //   image: IconsPath.lockIcon,
              //   avaterColor: AppColors.primaryColor,
              //   text: "change_language".tr,
              //   onTap: () {
              //     showModalBottomSheet(
              //       context: context,
              //       backgroundColor: Colors.black,
              //       shape: RoundedRectangleBorder(
              //         borderRadius: BorderRadius.vertical(
              //           top: Radius.circular(16),
              //         ),
              //       ),
              //       builder:
              //           (_) => Padding(
              //             padding: const EdgeInsets.all(16.0),
              //             child: Column(
              //               mainAxisSize: MainAxisSize.min,
              //               children: [
              //                 ListTile(
              //                   leading: const Icon(
              //                     Icons.language,
              //                     color: Colors.white,
              //                   ),
              //                   title: Text(
              //                     'English',
              //                     style: TextStyle(color: Colors.white),
              //                   ),
              //                   onTap: () {
              //                     Get.updateLocale(Locale('en', 'US'));
              //                     Get.back();
              //                   },
              //                 ),

              //                 ListTile(
              //                   leading: const Icon(
              //                     Icons.language,
              //                     color: Colors.white,
              //                   ),
              //                   title: Text(
              //                     'Deutsch',
              //                     style: TextStyle(color: Colors.white),
              //                   ),
              //                   onTap: () {
              //                     Get.updateLocale(Locale('de', 'DE'));
              //                     Get.back();
              //                   },
              //                 ),
              //               ],
              //             ),
              //           ),
              //     );
              //   },
              // ),

              // Language selection section
              Container(
                padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: Colors.white.withValues(alpha: 0.06),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Icon(
                            Icons.language,
                            color: Colors.white.withValues(alpha: 0.6),
                            size: 18,
                          ),
                        ),
                        SizedBox(width: 20),
                        Text(
                          "language".tr,
                          style: globalTextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                    FlutterSwitch(
                      width: 70.0,
                      height: 35.0,
                      toggleSize: 30.0,
                      value: controller.islanguageSwitch.value,
                      borderRadius: 30.0,
                      padding: 4.0,
                      activeColor: Colors.white.withValues(alpha: 0.18),
                      inactiveColor: Colors.white.withValues(alpha: 0.18),
                      showOnOff: true,
                      toggleColor: AppColors.primaryColor,
                      activeText: "GE",
                      inactiveText: "EN",
                      activeTextFontWeight: FontWeight.w600,
                      inactiveTextFontWeight: FontWeight.w600,
                      activeTextColor: Colors.white,
                      inactiveTextColor: Colors.white,
                      onToggle: controller.toggleLanguageSwitch,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 18),
              ProfileContentContainer(
                containerColor: Colors.white.withValues(alpha: 0.06),
                textColor: Colors.white,
                image: IconsPath.lockIcon,
                avaterColor: AppColors.primaryColor,
                text: "delete_account".tr,
                onTap: () {
                  controller.deletedAccount(
                    controller.userProfile.value!.data.id,
                  );
                },
              ),
              SizedBox(height: 28),

              ProfileContentContainer(
                containerColor: Color(0xFFFF4B4B),
                textColor: Colors.white,
                image: IconsPath.logout,
                text: "logout".tr,
                onTap: () {
                  controller.logout();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
