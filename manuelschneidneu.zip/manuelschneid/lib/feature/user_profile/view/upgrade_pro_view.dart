import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:manuelschneid/core/const/app_colors.dart';
import 'package:manuelschneid/core/const/icons_path.dart';
import 'package:manuelschneid/core/global_widegts/custom_buttom.dart';
import 'package:manuelschneid/core/style/global_text_style.dart';
import 'package:manuelschneid/feature/user_profile/view/widgets/subscriptions_card.dart';

import '../controller/subscription_controller.dart';

class UpgradeProView extends StatelessWidget {
  UpgradeProView({super.key});

  final SubscriptionController controller = Get.put(SubscriptionController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.appBackgroundColor,
        leading: Padding(
          padding: EdgeInsets.only(left: 20),
          child: GestureDetector(
            onTap: () => Get.back(),
            child: CircleAvatar(
              radius: 21,
              backgroundColor: Color(0xFFF1F2F6).withOpacity(0.1),
              child: Center(
                child: Icon(Icons.arrow_back_ios_new, color: Colors.white),
              ),
            ),
          ),
        ),
        title: Text(
          "upgrade_to_pro".tr,
          style: globalTextStyle(
            color: Color(0xFFF1F2F6),
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator(color: Colors.teal));
        }

        if (controller.subscriptionPlans.isEmpty) {
          return Center(
            child: Text(
              "no_plans_available.".tr,
              style: globalTextStyle(color: Colors.white70, fontSize: 16),
            ),
          );
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 30, 14, 30),
          child: Column(
            children: [
              Center(
                child: Column(
                  children: [
                    Image.asset(IconsPath.subscription, width: 68, height: 52),
                    SizedBox(height: 10),
                    Text(
                      "get_premium".tr,
                      style: globalTextStyle(
                        color: Color(0xFFF1F2F6),
                        fontSize: 32,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        "upgrade_plan_message".tr,
                        textAlign: TextAlign.center,
                        style: globalTextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              ...List.generate(controller.subscriptionPlans.length, (index) {
                final plan = controller.subscriptionPlans[index];
                return SubscriptionCard(
                  plan: plan,
                  isSelected: controller.selectedIndex.value == index,
                  onTap: () => controller.selectPlan(index),
                );
              }),
              Spacer(),
              CustomButtom(
                text: "continue".tr,
                ontap: () {
                  // final selectedPlan =
                  //     controller.subscriptionPlans[controller
                  //         .selectedIndex
                  //         .value];
                  // final amount = selectedPlan['amount'].toDouble();
                  // final planId = selectedPlan['id'];

                  // controller.makeStripePayment(amount, planId, "USD");
                },
              ),
              SizedBox(height: 14),
            ],
          ),
        );
      }),
    );
  }
}
