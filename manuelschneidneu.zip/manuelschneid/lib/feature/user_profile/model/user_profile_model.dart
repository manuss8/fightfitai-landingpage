class UserProfileModel {
  final bool success;
  final String message;
  final UserProfileData data;

  UserProfileModel({
    required this.success,
    required this.message,
    required this.data,
  });

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    return UserProfileModel(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data: UserProfileData.fromJson(json['data']),
    );
  }
}

class UserProfileData {
  final String id;
  final String email;
  final String userName;
  final String profileImage;
  final bool isPayment;
  final int points;
  final String createdAt;
  final String updatedAt;

  UserProfileData({
    required this.id,
    required this.email,
    required this.userName,
    required this.profileImage,
    required this.isPayment,
    required this.points,
    required this.createdAt,
    required this.updatedAt,
  });

  factory UserProfileData.fromJson(Map<String, dynamic> json) {
    return UserProfileData(
      id: json['id'] ?? '',
      email: json['email'] ?? '',
      userName: json['userName'] ?? '',
      profileImage: json['profileImage'] ?? '',
      isPayment: json['isPayment'] ?? false,
      points: json['points'] ?? 0,
      createdAt: json['createdAt'] ?? '',
      updatedAt: json['updatedAt'] ?? '',
    );
  }
}
