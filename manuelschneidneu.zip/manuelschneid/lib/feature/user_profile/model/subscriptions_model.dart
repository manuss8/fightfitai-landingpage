class SubscriptionPlanModel {
  final String duration;
  final String price;
  final String perMonthPrice;

  SubscriptionPlanModel({
    required this.duration,
    required this.price,
    required this.perMonthPrice,
  });
}
