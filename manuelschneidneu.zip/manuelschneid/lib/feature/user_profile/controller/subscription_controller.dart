import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:manuelschneid/core/network_caller/endpoints.dart';

import 'package:shared_preferences/shared_preferences.dart';

class SubscriptionController extends GetxController {
  RxInt selectedIndex = 2.obs;
  var isLoading = false.obs;
  var subscriptionPlans = <Map<String, dynamic>>[].obs;

  void selectPlan(int index) {
    selectedIndex.value = index;
  }

  @override
  void onInit() {
    fetchSubscriptionStatus();
    super.onInit();
  }

  Future<void> fetchSubscriptionStatus() async {
    isLoading.value = true;
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      if (kDebugMode) {
        print('Token not found in SharedPreferences');
      }
      return;
    }

    final url = Uri.parse('${Urls.baseUrl}/subscription-plan');

    try {
      final response = await http.get(
        url,
        headers: {'Content-Type': 'application/json', 'Authorization': token},
      );

      if (kDebugMode) {
        print("The response for fetching plans is: ${response.statusCode}");
      }

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonData = jsonDecode(response.body);

        print("/////////////////subscription plans: ${response.body}");

        if (jsonData['success'] == true) {
          final List<dynamic> data = jsonData['data'];
          subscriptionPlans.value = List<Map<String, dynamic>>.from(data);
        } else {
          if (kDebugMode) {
            print('Failed to fetch subscription plans');
          }
        }
      } else {
        if (kDebugMode) {
          print('Error: ${response.statusCode}');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error: $e');
      }
    } finally {
      isLoading.value = false;
    }
  }

  // void makeStripePayment(double price, String planID, String currency) async {
  //   if (kDebugMode) {
  //     print(price);
  //     print(planID);
  //     print(currency);
  //   }
  //   bool isSuccess = await StripeService.instance.makePayment(price, currency);

  //   if (isSuccess) {
  //     submitPayment(planID);
  //   } else {
  //     if (kDebugMode) {
  //       print("Stripe Payment failed");
  //     }
  //   }
  // }

  void submitPayment(String planID) async {
    if (kDebugMode) {
      print("///////////////The Submit payment method is called");
    }
    try {
      EasyLoading.show(status: "Loading".tr);
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';

      final body = jsonEncode({"planId": planID});

      final response = await http.post(
        Uri.parse("${Urls.baseUrl}/users/payment/$planID"),
        headers: {"Authorization": token, "Content-Type": "application/json"},
        body: body,
      );

      if (kDebugMode) {
        print(
          '/////////////////////////Response status code: ${response.body}',
        );
      }

      if (response.statusCode == 200) {
        prefs.setBool('success', true);
        EasyLoading.showSuccess("success".tr);
        Get.back();
      } else {
        EasyLoading.showError("try_after_some_time".tr);
      }
    } catch (e) {
      EasyLoading.showError("try_after_some_time".tr);
      if (kDebugMode) {
        print('/////////////////////////Error: $e');
      }
    } finally {
      EasyLoading.dismiss();
    }
  }
}
