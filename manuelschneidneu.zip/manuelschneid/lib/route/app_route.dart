import 'package:get/get.dart';
import 'package:manuelschneid/feature/auth/forget_password/view/forget_password_view.dart';
import 'package:manuelschneid/feature/auth/login/view/login_view.dart';
import 'package:manuelschneid/feature/auth/register/view/register_view.dart';
import 'package:manuelschneid/feature/bottom_navbar/view/bottom_navbar_view.dart';
import 'package:manuelschneid/feature/admin/admin_profile/view/admin_profile_view.dart';
import 'package:manuelschneid/feature/splash_screen/screen/splash_screen.dart'
    show SplashScreen;

class AppRoute {
  static const String splashScreen = '/splashScreen';
  static const String forgetPasswordScreen = '/forgetPasswordScreen';
  static const String signupScreen = '/signupScreen';
  static const String signinScreen = '/signinScreen';
  static const String bottomNavbarScreen = '/bottomNavbarScreen';
  static const String profile = '/profile';
  static const String adminProfile = '/adminProfile';

  // static String getSplashScreen() => splashScreen;
  // static String getForgetPasswordScreen() => forgetPasswordScreen;
  // static String getsignupScreen() => signupScreen;
  // static String getsigninScreen() => signinScreen;

  static List<GetPage> routes = [
    GetPage(name: splashScreen, page: () => SplashScreen()),
    GetPage(name: signupScreen, page: () => RegisterView()),
    GetPage(name: signinScreen, page: () => LoginView()),
    GetPage(name: forgetPasswordScreen, page: () => ForgetPasswordView()),
    GetPage(name: adminProfile, page: () => AdminProfileView()),
    GetPage(name: bottomNavbarScreen, page: () => BottomNavbarView()),
  ];
}
